# SmartTube PS4 — v2.8 development source

SmartTube-inspired PS4 homebrew development scaffold. **Not an installable PKG.**

## v2.8 changes

- Corrected the DualShock 4 event queue capacity to match the ten buttons actually mapped, avoiding misleading spare capacity.
- Added a compiled-and-run host application smoke test to the standard test script (not just library unit tests).
- Corrected the toolchain diagnostic so it distinguishes the existing but unverified Pad adapter from the still-missing native renderer and AV-player implementation.
- Updated application and target metadata to `2.8.0-dev`.
- These are portable project-quality fixes; no PS4-native build or console validation is included.

## v2.7 changes

- Hardened viewport mapping against zero-sized, corrupted, or hand-edited viewport state.
- Rejects invalid draw-command kinds and verifies transformed geometry remains finite and inside the output surface.
- Added a zero-initializer macro for the graphics device lifecycle and clarified the required initialization contract.
- Corrected target metadata to report the current development version.
- These are portable correctness fixes; no native PS4 renderer or console build is included.

## v2.6 changes

- Hardened graphics backend initialization cleanup: if platform initialization fails after partially acquiring resources, the backend shutdown callback is invoked to release them.
- Documented the zero-initialization requirement for the graphics device lifecycle.
- Added regression coverage for partial-init cleanup and begin-frame failure (no draw/end calls are issued when a frame never begins).
- This remains a portable graphics lifecycle contract; no PS4 GPU implementation or console validation is included.

## v2.4 changes

- Added a graphics-device lifecycle contract for backend initialization, output dimensions, frame presentation, and idempotent shutdown.
- Added dimension and callback validation plus failure-path tests using a fake graphics backend.
- The renderer still has no PS4 GPU implementation; this milestone prepares the integration seam only. See `docs/V2.4_GRAPHICS_LIFECYCLE.md`.

## v2.3 changes

- Hardened the renderer adapter by validating the complete draw list before opening a frame.
- Rejects oversized lists, unsupported command kinds, non-finite/negative geometry, out-of-screen geometry, and unterminated text buffers.
- Added tests proving malformed frames are rejected without beginning a partial render, and draw failures still close the frame.
- This is renderer-contract hardening only; no PS4 GPU calls or native graphics backend are included.

## v2.2 changes

- Reworked the renderer-neutral 1080p home screen into a featured-panel and tile dashboard.
- Added focus-outline draw commands and geometry-bound tests.
- No PS4-native GPU backend is included; see `docs/V2.2_DASHBOARD.md`.

## v2.1 changes

- Added a host-tested DualShock 4 button-mask decoder with one-shot press events and simultaneous-event buffering.
- Added an optional OpenOrbis Pad adapter source for native controller initialization, polling, and cleanup.
- See `docs/V2.1_DUALSHOCK4.md`; PS4 cross-compilation and hardware validation are still pending.

## v2.0 changes

- Added a platform shutdown callback to the runtime adapter contract.
- Exit requests now return a terminal runtime result without drawing another frame.
- Platform cleanup is invoked at most once, even if the caller mistakenly polls the runtime again.
- Added host tests for shutdown notification and no-render-after-exit.
- This is a portable lifecycle contract, not a PS4-native process exit implementation.

## v1.9 changes

- Runtime now drains a bounded batch of controller events per frame (maximum 16) to preserve responsiveness without starving rendering.
- Mapped the Options button to an explicit application exit request.
- Added host coverage for ordered event batching, exit dispatch, and input failure.
- This remains a portable contract; no PS4 controller SDK binding or native process shutdown is included.

## v1.8 changes

- Added a PS4 toolchain readiness diagnostic for common OpenOrbis compiler and packaging-tool locations.
- Corrected target metadata so SponsorBlock's implemented portable pipeline is not incorrectly marked as wholly outstanding.
- Documented the remaining native PS4 entrypoint, graphics, controller, AV-player, and packaging work.
- This is a readiness/diagnostics milestone, not a PS4 executable or real playback implementation.

## v1.7 changes

- Added a platform AV-player adapter boundary mapping open/start/pause/seek/time/close operations into the portable media backend.
- Added host tests for adapter mapping, backend failure, time reporting, and idempotent cleanup.
- This remains an adapter seam: no verified PS4 AV-player binding or real decoder/output is included.

## v1.6 changes

- Added a playback-session lifecycle coordinator over the media backend contract.
- Added explicit playback states, URI scheme filtering, seek clamping, position validation, end detection, and backend-failure handling.
- Added host tests for playback-session lifecycle and cleanup.
- This is not yet a real decoder/streaming backend; see `docs/V1.6_PLAYBACK_SESSION.md`.

## v1.5 changes

- SponsorBlock auto-skip state rearms after rewinding before the last skipped segment.
- Skip result output is cleared on every player tick.
- Host tests cover rewind/replay behavior.

## v1.3 changes
- Added bounded parsing for the SponsorBlock k-anonymity response envelope, selecting only the exact requested video ID before parsing its segment array.
- Added matching/nonmatching and malformed-response tests. No live API request or playback seek is performed.

## v1.1 changes
- Added optional libcurl/OpenSSL HTTPS GET transport with TLS peer/hostname verification, host restriction, timeouts, and bounded response buffering.
- Added SHA-256 four-character k-anonymity request URL construction so the video ID itself is not sent to SponsorBlock.
- Added privacy/transport boundary tests. These tests do not make a live network request and do not establish PS4 compatibility.

## v1.0 changes
- Added a bounded SponsorBlock `skipSegments` JSON parser with category/interval extraction, duration validation, unknown-field tolerance, malformed-input checks, and capacity checks.
- Added parser tests; all eight host test suites pass with the included C11 test script.

## v0.9 changes
- Added a bounded native SponsorBlock API request builder using the documented `GET /api/skipSegments` endpoint and enabled categories.
- Added request validation and host tests for URL construction and buffer safety.

## v0.8 changes
- Added a native runtime frame coordinator connecting controller polling, action mapping, app state, UI model, renderer-neutral draw commands, and platform presentation.
- Added host tests for the complete input-to-render path.
- Ensured a failed draw closes the active frame through the adapter contract.

## v0.7 changes
- Media backend interface with validation and explicit unavailable/error results.
- Host tests for the backend contract using a fake test backend.
- Corrected Home menu routing and added an About screen.
- Prior UI model, renderer-neutral draw list, controller mapping, settings, and SponsorBlock policy remain.

## Check PS4 toolchain prerequisites

```sh
./scripts/check_ps4_toolchain.sh
```

This diagnostic does not build a SELF or PKG.

## Run host tests
Requires a C11 compiler (GCC or Clang):

```sh
./scripts/run_host_tests.sh
```

The fake media and AV-player backends are test doubles. No real video/audio playback is implemented.

## Current limitations
- The renderer adapter validates command lists and v2.4 adds a portable graphics-device lifecycle, but there is still no PS4 GPU implementation, shader, font atlas, or texture backend.
- The v1.7 AV-player adapter requires a separately verified platform operation table; the included host fake does not decode media. The current OpenOrbis AvPlayer header has placeholder declarations, so no ABI-unsafe direct calls are made.
- No PS4 SDK/OpenOrbis native graphics/input adapter is included.
- No actual PS4 video decoder, audio output, or streaming backend is included. v1.6 adds the playback-session lifecycle only; it does not decode or play media.
- SponsorBlock direct-ID URL construction, bounded JSON parsing, optional host libcurl/OpenSSL HTTPS transport, and k-anonymity URL construction are implemented. The k-anonymity response envelope selection and segment parser are connected through the pipeline. A portable player coordinator can trigger seeks through the generic media-backend callback contract; there is still no actual PS4 playback backend. The HTTPS module requires a PS4-compatible port/toolchain integration before console use.
- YouTube platform-served ads are not bypassed; provider playback and advertising rules must be respected.
- Firmware 14.02 and GoldHEN 2.4b18.14 are user-reported targets, not independently verified compatibility.
- No SELF, GP4, or installable PKG has been produced.

## Next engineering steps
1. Verify the available AV-player API signatures and runtime module support in the chosen PS4 toolchain, then implement the platform operation table behind the v1.7 adapter.
2. Add platform-specific PS4 graphics, controller, and networking adapters using a compatible homebrew toolchain.
3. Build and test on target PS4 hardware before claiming compatibility.
4. Produce and validate a GP4/PKG package only after the native application and dependencies build successfully.

## v1.3 changes
- Added `sponsorblock_pipeline` to connect private k-anonymity requests, HTTPS transport, exact-video response parsing, and next-eligible-segment selection.
- Added offline pipeline tests with an injected fake transport. This does not perform a live network request or seek a real player.

### v1.4 player seek coordinator
The new `sponsorblock_player` module connects the segment pipeline to the generic media backend: poll it during playback and it seeks to an eligible segment's end when playback reaches the configured trigger window. This remains an adapter contract, not a real video player. A platform-specific decoder/streaming backend and PS4 integration are still required.

## v2.1 development status — DualShock 4 input bridge

The portable DS4 decoder and press-edge queue are implemented and host-tested. An optional OpenOrbis Pad adapter now provides the hardware boundary for opening and polling a controller. The application must initialize the PS4 user service first and pass the active user ID plus the controller type/index appropriate to the installed OpenOrbis headers. This adapter has not been cross-compiled or tested on a PS4 in this environment.

The existing renderer and AV-player interfaces remain contracts only. No native PS4 graphics backend, verified AV-player binding, actual video/audio playback, SELF, or PKG is included yet.


## v2.6 graphics viewport utility

The renderer-neutral viewport maps the 1920x1080 logical dashboard to an output surface using uniform aspect-fit scaling and centered letterboxing. It does not perform GPU rendering and is not a PS4 graphics backend. Run `scripts/run_host_tests.sh` for host validation.

## v2.7 validation fixes
See `docs/V2.7_VALIDATION_FIXES.md` for viewport-state validation, explicit initialization macros, metadata corrections, and regression coverage.

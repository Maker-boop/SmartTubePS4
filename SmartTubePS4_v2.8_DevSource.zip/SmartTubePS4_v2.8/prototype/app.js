const $ = (s) => document.querySelector(s);
const categories = [
  ['sponsor','Paid sponsor messages'],['intro','Intros'],['outro','Outros and end cards'],
  ['selfpromo','Creator self-promotion'],['interaction','Like / subscribe reminders'],
  ['preview','Previews / recaps'],['filler','Filler'],['music_offtopic','Off-topic music']
];
const defaults = { enabled:true, auto:true, notify:true, categories:['sponsor','selfpromo','interaction'] };
let prefs = {...defaults};
try { prefs = {...defaults, ...JSON.parse(localStorage.getItem('stps4-prefs') || '{}')}; } catch {}
let segments = [];
let simTimer = null;
const categoryHost = $('#categories');
for (const [key,label] of categories) {
  const row = document.createElement('label'); row.className='category';
  const input = document.createElement('input'); input.type='checkbox'; input.dataset.category=key; input.checked=prefs.categories.includes(key);
  const span = document.createElement('span'); span.textContent=label;
  row.append(span,input); categoryHost.append(row);
  input.addEventListener('change', () => { prefs.categories = [...document.querySelectorAll('[data-category]:checked')].map(x=>x.dataset.category); savePrefs(); });
}
function savePrefs(){
  prefs.enabled=$('#sb-enabled').checked; prefs.auto=$('#sb-auto').checked; prefs.notify=$('#sb-notify').checked;
  prefs.categories=[...document.querySelectorAll('[data-category]:checked')].map(x=>x.dataset.category);
  localStorage.setItem('stps4-prefs',JSON.stringify(prefs));
}
$('#sb-enabled').checked=prefs.enabled; $('#sb-auto').checked=prefs.auto; $('#sb-notify').checked=prefs.notify;
['#sb-enabled','#sb-auto','#sb-notify'].forEach(s=>$(s).addEventListener('change',savePrefs));
function toast(msg){ const t=$('#toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(toast.timer); toast.timer=setTimeout(()=>t.classList.remove('show'),2600); }
function showPage(page){
  document.querySelectorAll('.nav').forEach(x=>x.classList.toggle('active',x.dataset.page===page));
  $('#page-title').textContent=page;
  $('#hero').hidden=!['Home'].includes(page);
  $('#discover-head').hidden=!['Home','Search','Subscriptions','Library','Favorites'].includes(page);
  $('#cards').hidden=!['Home','Search','Subscriptions','Library','Favorites'].includes(page);
  $('#settings-panel').hidden=page!=='Settings'; $('#player-panel').hidden=page!=='Player';
  $('#simple-panel').hidden=!['Subscriptions','Library','Favorites'].includes(page);
  if(page==='Settings') $('#section-title').textContent='Settings';
  if(['Subscriptions','Library','Favorites'].includes(page)){ $('#simple-title').textContent=page; $('#section-title').textContent=page; }
  if(page==='Search'){ $('#section-title').textContent='Search results'; $('#search').focus(); }
  if(page==='Home') $('#section-title').textContent='Recommended';
}
document.querySelectorAll('.nav').forEach(btn=>btn.addEventListener('click',()=>showPage(btn.dataset.page)));
$('#explore').addEventListener('click',()=>$('#search').focus());
$('#search').addEventListener('keydown',e=>{if(e.key==='Enter'){showPage('Search'); const q=e.target.value.trim(); $('#section-title').textContent=q?`Results for “${q}”`:'Search videos'; toast('Catalog search is not connected in this prototype.');}});
document.querySelectorAll('.video-card').forEach(card=>{
  const open=()=>{ $('#player-title').textContent=card.dataset.title; showPage('Player'); };
  card.addEventListener('click',open); card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open();}});
});
function fmt(sec){const n=Math.max(0,Math.floor(sec));return `${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;}
function updateTimeline(){const n=Number($('#timeline').value);$('#time-label').textContent=`${fmt(n)} / 10:00`;}
$('#timeline').addEventListener('input',updateTimeline);
function activeSegment(t){return segments.find(s=>t>=s.start&&t<s.end&&prefs.categories.includes(s.category));}
function renderSegments(){
  const host=$('#segments'); host.replaceChildren();
  if(!segments.length){host.innerHTML='<p class="muted">No matching segments returned for this video and category selection.</p>';return;}
  segments.forEach(s=>{const row=document.createElement('div');row.className='segment-row';const info=document.createElement('div');const name=document.createElement('b');name.textContent=s.category;const time=document.createElement('small');time.textContent=`${fmt(s.start)} – ${fmt(s.end)} · ${Math.round(s.end-s.start)} sec`;info.append(name,time);const jump=document.createElement('button');jump.className='secondary';jump.textContent='Jump to start';jump.addEventListener('click',()=>{$('#timeline').value=Math.floor(s.start);updateTimeline();});row.append(info,jump);host.append(row);});
}
async function lookup(){
  const id=$('#video-id').value.trim();
  if(!/^[A-Za-z0-9_-]{11}$/.test(id)){toast('Enter a valid 11-character YouTube video ID.');return;}
  if(!prefs.enabled){toast('SponsorBlock is turned off in Settings.');return;}
  $('#lookup-status').textContent='Contacting SponsorBlock…'; $('#segments').innerHTML='<p class="muted">Loading…</p>';
  const cats=prefs.categories.length?prefs.categories:['sponsor'];
  const params=new URLSearchParams({videoID:id,categories:JSON.stringify(cats)});
  try{
    const response=await fetch(`https://sponsor.ajay.app/api/skipSegments?${params.toString()}`,{headers:{'Accept':'application/json'}});
    if(response.status===404){segments=[];$('#lookup-status').textContent='SponsorBlock has no submitted segments for this video and category selection.';renderSegments();return;}
    if(!response.ok) throw new Error(`SponsorBlock returned HTTP ${response.status}`);
    const data=await response.json();
    segments=data.filter(s=>Array.isArray(s.segment)&&s.segment.length===2).map(s=>({start:Number(s.segment[0]),end:Number(s.segment[1]),category:s.category,uuid:s.UUID})).filter(s=>Number.isFinite(s.start)&&Number.isFinite(s.end)&&s.end>s.start).sort((a,b)=>a.start-b.start);
    $('#lookup-status').textContent=`Found ${segments.length} submitted segment${segments.length===1?'':'s'} for ${id}.`;
    renderSegments();
  }catch(err){segments=[];$('#lookup-status').textContent=`Lookup failed: ${err.message}. Check internet access or try again later.`;renderSegments();}
}
$('#lookup').addEventListener('click',lookup); $('#video-id').addEventListener('keydown',e=>{if(e.key==='Enter')lookup();});
$('#check-skip').addEventListener('click',()=>{
  if(!prefs.enabled){toast('SponsorBlock is disabled.');return;}
  const t=Number($('#timeline').value), s=activeSegment(t);
  if(!s){toast('No enabled SponsorBlock segment at this timestamp.');return;}
  if(prefs.auto){$('#timeline').value=Math.ceil(s.end);updateTimeline();toast(prefs.notify?`Skipped ${s.category} segment.`:'Segment skipped.');}
  else toast(`Detected ${s.category}: ${fmt(s.start)}–${fmt(s.end)}. Manual skip is enabled.`);
});
$('#play-pause').addEventListener('click',()=>{
  if(simTimer){clearInterval(simTimer);simTimer=null;$('#play-pause').textContent='▶ Play simulation';return;}
  $('#play-pause').textContent='Ⅱ Pause simulation';
  simTimer=setInterval(()=>{let t=Number($('#timeline').value)+1;const s=prefs.enabled&&prefs.auto?activeSegment(t):null;if(s){t=Math.ceil(s.end);if(prefs.notify)toast(`Skipped ${s.category} segment.`);}$('#timeline').value=Math.min(600,t);updateTimeline();if(t>=600){clearInterval(simTimer);simTimer=null;$('#play-pause').textContent='▶ Play simulation';}},1000);
});
$('#reset-time').addEventListener('click',()=>{$('#timeline').value=0;updateTimeline();});
// Simple keyboard/controller-style focus movement for desktop preview.
document.addEventListener('keydown',e=>{if(['ArrowDown','ArrowUp'].includes(e.key)&&document.activeElement.tagName!=='INPUT'){const items=[...document.querySelectorAll('.nav:not([disabled]),.video-card')].filter(x=>!x.closest('[hidden]'));const i=items.indexOf(document.activeElement);if(i>=0){e.preventDefault();items[Math.max(0,Math.min(items.length-1,i+(e.key==='ArrowDown'?1:-1)))].focus();}}});

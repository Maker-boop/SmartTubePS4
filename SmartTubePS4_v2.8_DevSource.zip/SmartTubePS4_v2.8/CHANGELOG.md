# Changelog

## v2.8.0-dev
- Match the DS4 event queue capacity to the ten mapped controls.
- Add a host application smoke build/run to the standard validation script.
- Clarify toolchain diagnostics: controller adapter source exists but remains unverified; native renderer and AV-player binding are still pending.
- Update version metadata to 2.8.0-dev.


## v2.7.0-dev
- Validate viewport dimensions and derived aspect-fit transform before mapping draw commands.
- Reject invalid draw kinds and non-finite/out-of-bounds transformed geometry.
- Add explicit zero-initializer macro for graphics-device state.
- Fix stale target version metadata.


## v2.4.0-dev
- Added portable graphics backend lifecycle wrapper with initialization, bounded output dimensions, frame presentation, and idempotent shutdown.
- Added fake-backend host tests for initialization failure, duplicate initialization, draw failure cleanup, and shutdown behavior.
- No PS4 GPU API implementation or console build is included.

# Changelog

## v2.3 — Renderer adapter validation

- Added full-frame validation before platform rendering begins.
- Added rejection of oversized, unsupported, non-finite, negative, out-of-bounds, and unterminated-text draw commands.
- Added regression tests for malformed-frame rejection and draw-failure cleanup.
- No PS4-native graphics backend or PKG is included.


## v0.6.0
- Added renderer-neutral 1920x1080 draw-command generation for the SmartTube-inspired dark UI.
- Added a platform presentation adapter contract for frame begin/draw/end.
- Added host tests for draw-list generation and adapter dispatch.
- Preserved prior application state, controller mapping, settings, and SponsorBlock policy modules.
- Explicitly documents that a real PS4 graphics/controller adapter and media backend remain unimplemented.


## v0.7
- Added a validated media-backend callback contract (open/play/pause/seek/position/close).
- Added host tests using a fake backend; no real media streaming is claimed.
- Added About screen and corrected Home menu routing for all five entries.
- Retained the SponsorBlock policy module; API transport and player seek integration remain future work.


## v0.8
- Added `st_runtime_frame` to connect controller polling to application actions and rendered frames.
- Defined explicit platform input polling return semantics and runtime error results.
- Added runtime integration tests covering controller-to-render flow.
- Ensured the platform presentation adapter attempts frame cleanup after a draw failure.
- This remains a host-tested integration seam; a real PS4 SDK graphics/controller adapter is not included.

## v0.9 — SponsorBlock request layer
- Added a bounded native request builder for the SponsorBlock `GET /api/skipSegments` endpoint.
- Validates the 11-character YouTube video ID alphabet and requires at least one enabled category.
- Sends enabled categories as repeated `category` query parameters and explicitly requests `actionType=skip` for the YouTube service.
- Added host tests for valid requests, invalid IDs, no enabled categories, and insufficient output buffers.
- This is request construction only: HTTPS transport, JSON decoding, response caching, and player seek integration remain unimplemented.


## v1.0 — SponsorBlock response parsing
- Added a bounded, allocation-free JSON parser for SponsorBlock `skipSegments` response arrays.
- Extracts category and segment interval fields while tolerating additional API fields.
- Validates each interval against the supplied media duration and ignores unknown categories.
- Rejects malformed JSON and output-capacity overflow; added dedicated parser tests.
- HTTPS transport, response caching, k-anonymity lookup, player seek integration, and PS4 testing remain outstanding.

## v1.1 — SponsorBlock HTTPS and privacy groundwork
- Added libcurl/OpenSSL HTTPS GET transport with certificate/hostname verification, bounded response writes, timeouts, and HTTP status reporting.
- Added SHA-256 k-anonymity URL construction (four-character prefix) to avoid sending raw video IDs.
- Added optional host tests when libcurl/OpenSSL development packages are present.
- No live request, PS4 build, player seek, or console test is claimed.

## v1.2
- Added bounded SponsorBlock k-anonymity response-envelope parsing.
- Selects the exact video ID entry and ignores unrelated IDs.
- Added tests for matching, nonmatching, malformed, and invalid-capacity cases.

## v1.3
- Connected private k-anonymity URL construction, injectable HTTPS transport, k-anonymity response parsing, and segment selection in a single bounded pipeline.
- Added offline end-to-end pipeline tests using a fake transport.
- Player seeking remains an adapter responsibility; no actual playback backend is present.

## v1.4
- Added a SponsorBlock player coordinator that connects eligible segments to the generic media-backend position/seek callbacks.
- Added trigger-window handling, automatic-skip gating, duplicate-seek protection, and explicit backend error results.
- Added offline fake-backend integration tests.

## v1.5

- Rearm SponsorBlock segment skipping after playback rewinds before the last skipped segment.
- Clear optional skipped-segment output on each tick to avoid stale UI state.
- Expand host tests for rewind/replay and output hygiene.


## v1.6 — Playback session layer
- Added `st_player_session_t` to coordinate open/play/pause/seek/update/close over the media backend interface.
- Added explicit playback lifecycle states and media-generation tracking.
- Added supported URI scheme checks, duration-aware seek clamping, position validation, and end-of-media detection.
- Added host lifecycle and error-path tests.
- No decoder, audio output, real network stream, PS4 SDK binding, or installable PKG is included yet.

## v1.7 development step — AV-player adapter boundary
- Added a platform-operation adapter that maps open/start/pause/seek/time/close operations into the existing media backend contract.
- Added lifecycle, failure, time-query, and idempotent-close host tests.
- This is an integration seam only. No Sony AV-player implementation, decoder, audio/video output, or PS4 SDK binding is included.

## v1.8 — PS4 platform readiness
- Added an OpenOrbis toolchain-path diagnostic with optional strict failure mode.
- Corrected project target metadata for the SponsorBlock pipeline and PS4 implementation status.
- Documented the missing native entrypoint, graphics/controller bindings, verified AV-player ABI, and packaging steps.
- No PS4 executable or PKG is claimed.

## v1.9 — Runtime input and exit handling
- Drain up to 16 controller events per frame to avoid one-event-per-frame input lag.
- Map Options to an explicit exit request and stop consuming events after exit is requested.
- Expand runtime tests for event ordering, exit dispatch, and input errors.
- PS4-specific polling and process termination remain platform integration tasks.

## v2.0 — Application shutdown lifecycle
- Added optional platform shutdown callback.
- Return a terminal exit-request result immediately after Options is dispatched; do not render another frame.
- Guarantee shutdown callback is notified at most once.
- Add host coverage for terminal behavior and idempotent cleanup.
- PS4-specific resource release and process termination remain unimplemented.

## v2.1 development milestone — DualShock 4 input bridge

- Added a portable DualShock 4 button-mask decoder using the documented OpenOrbis Pad button bit values.
- Added press-edge detection so held buttons do not generate repeated actions, plus bounded event buffering for simultaneous button presses.
- Added an optional OpenOrbis `scePadInit` / `scePadOpen` / `scePadReadState` / `scePadClose` controller adapter.
- Added host tests for button mapping, simultaneous presses, held-button behavior, release/re-press behavior, and invalid arguments.
- The PS4-specific adapter is source-only until compiled with the configured OpenOrbis toolchain and validated on console hardware. Native rendering and real video/audio playback remain unfinished.

## v2.2.0-dev — Dashboard rendering model

- Reworked the 1920x1080 home screen into a featured-panel and content-tile dashboard.
- Added focused tile outline draw commands and consistent secondary-screen row layout.
- Added renderer command bounds and focus-outline tests.
- Updated the development version metadata to v2.2.0-dev.
- This remains renderer-neutral; no native PS4 GPU backend or installable PKG is included.

## v2.6.0-dev — Resolution-independent viewport mapping
- Added a renderer-neutral aspect-fit viewport for mapping the fixed 1920x1080 UI canvas to arbitrary nonzero output dimensions.
- Added centered letterboxing for non-16:9 outputs without distorting UI geometry.
- Added command mapping validation for non-finite values, negative geometry, out-of-canvas bounds, and unterminated text buffers.
- Added host tests for native 1080p mapping, 1280x1024 letterboxing, coordinate scaling, and invalid inputs.
- This remains a portable graphics utility; no PS4 GPU implementation, SDK linkage, console test, or PKG is included.

# Native PS4 implementation roadmap

## Added in v0.4
- Portable app screen state and focus navigation.
- Button-to-action mapping layer.
- Media backend interface contract for open/play/pause/seek/close.
- Host-side tests for navigation and playback state transitions.

## Remaining before a usable PKG
- Integrate a verified PS4 homebrew SDK/toolchain for the user's exact environment.
- Implement renderer, controller event polling, audio/video output, and lifecycle.
- Implement HTTPS transport and JSON parsing for SponsorBlock API responses.
- Connect SponsorBlock's validated segments to the real media player's seek callback.
- Select a lawful, technically compatible media source and playback implementation.
- Persist preferences, favorites, and watch history.
- Produce SELF `eboot.bin`, `param.sfo`, icon assets, GP4 metadata, PKG, and perform console testing.

The current portable C code is a state/policy scaffold. It does not fetch video, decode media, call SponsorBlock, or generate a PS4 executable.

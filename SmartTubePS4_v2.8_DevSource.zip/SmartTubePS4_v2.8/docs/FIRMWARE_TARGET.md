# PS4 target profile: firmware 14.02

User-reported target: PS4 firmware **14.02**, GoldHEN **2.4b18.14**.

A community report dated 2026-11-14 describes Afterglow on firmware 14.02 loading
GoldHEN 2.4b18.14. This project has not independently validated that report or
run a homebrew binary on the user's console. The official GoldHEN GitHub releases
page currently lists older firmware in its published supported-firmware section.

Do not treat this target profile as proof of compatibility. Before packaging:

1. Confirm the exact console firmware and GoldHEN build shown on the console.
2. Build and run a minimal OpenOrbis sample with the matching toolchain.
3. Confirm the app launches and can write/read its own data directory.
4. Only then integrate graphics, controller input, networking, and playback.

Do not update the console firmware as part of this project. No exploit or HEN
payload is bundled here.

# Native PS4 build and porting checklist

## Current state

The browser prototype is functional as a UI/API demonstration. The native C code now has a host-tested runtime frame coordinator that connects abstract controller polling, app state, UI model generation, draw commands, and a platform presentation adapter. The actual PS4 graphics/input adapter, network stack, video decoder, and package metadata are still absent. Therefore this project cannot currently produce a working PKG.

## Recommended implementation order

1. **Toolchain validation:** install the current OpenOrbis PS4 Toolchain using its upstream documentation and build an official minimal sample.
2. **Target validation:** verify the exact firmware 14.02 exploit/GoldHEN environment and confirm a minimal homebrew sample launches. Record the exact GoldHEN version.
3. **Graphics:** implement the 2D UI in a native renderer behind `st_platform_adapter_t`; use the browser prototype as the visual reference only.
4. **Controller:** implement `poll_button` using supported DualShock 4 APIs and map navigation, confirm/back, triggers, and text entry.
5. **Persistence:** store preferences, favorites, and watch history in an app-owned writable directory.
6. **Networking:** add HTTPS requests with certificate validation, timeouts, cancellation, and bounded response sizes.
7. **Playback:** choose an authorized source/backend whose terms permit the intended playback. Preserve normal YouTube ad behavior for YouTube playback.
8. **SponsorBlock:** implement the lookup and seek adapter described in `SPONSORBLOCK.md`.
9. **Packaging:** use the packaging tools and manifest format from the exact toolchain version; test installation and launch on the target console.

## Toolchain reference

- OpenOrbis PS4 Toolchain: https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain
- OpenOrbis organization: https://github.com/OpenOrbis

Follow upstream examples for current compiler flags, linker setup, ELF conversion, param.sfo generation, and package creation. Avoid copying commands from old tutorials without checking compatibility.

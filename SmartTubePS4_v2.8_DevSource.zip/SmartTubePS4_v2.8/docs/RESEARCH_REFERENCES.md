# v1.7 platform research references

The following upstream references informed the adapter boundary. They are not evidence of a working console build or media playback:

- OpenOrbis PS4 Toolchain overview and setup: https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain
- OpenOrbis `AvPlayer.h`: https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain/blob/master/include/orbis/AvPlayer.h
- OpenOrbis SDL2 sample build/package flow: https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain/blob/master/samples/SDL2/Makefile

The checked-in `AvPlayer.h` currently exposes placeholder function declarations without argument or return types. Do not invent prototypes from those placeholders. Verify ABI signatures and module availability against the exact toolchain/SDK environment before implementing the PS4 operation table.

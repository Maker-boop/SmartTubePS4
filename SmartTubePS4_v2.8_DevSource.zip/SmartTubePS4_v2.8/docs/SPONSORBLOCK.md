# SponsorBlock integration plan

## What it does

SponsorBlock is a community-maintained database of timestamps for portions of YouTube videos. It can identify creator-read sponsor messages and optional categories such as self-promotion, intros, outros, interaction reminders, previews, filler, and off-topic music.

It is **not** a platform-ad blocker. This project does not remove YouTube-served pre-roll, mid-roll, display, or other platform advertisements, and it must not interfere with ad playback in an official YouTube playback path.

## API lookup used by the prototype

The browser prototype calls:

`GET https://sponsor.ajay.app/api/skipSegments?videoID=VIDEO_ID&categories=["sponsor","selfpromo"]`

The response contains segment timestamps as `[startSeconds, endSeconds]` plus a category and UUID. A `404` means there are no matching submitted segments. The prototype validates the video ID, filters malformed timestamps, sorts the returned segments, and allows a simulated timeline to jump over selected categories.

The API can change. Before shipping, check the current SponsorBlock API documentation and respect its usage guidance, rate limits, privacy expectations, and attribution requirements.

## Native playback integration contract

The native player adapter should expose these operations/events:

- `get_video_id()` — return the canonical 11-character YouTube video ID when known.
- `get_position_seconds()` — return the current media timebase.
- `seek_to_seconds(target)` — seek to a target timestamp.
- `on_position_changed(position)` — call periodically during playback.
- `on_video_changed(video_id)` — discard stale segments and request the new video's data.

Skip algorithm:

1. On video change, request only the enabled categories.
2. Validate each segment (`start >= 0`, `end > start`, finite values).
3. Sort by start time and retain the category and UUID.
4. On each position update, find an enabled segment containing the current position.
5. If automatic skipping is enabled, seek to the segment end and optionally show a notification.
6. Prevent repeated seeks for the same segment during one playback session.
7. If lookup fails or the video ID is unknown, continue playback normally.

## Important boundary

SponsorBlock can skip creator-inserted sections only when the source/player provides a seekable timeline and the content has matching submitted data. It cannot reliably detect every sponsorship. Do not claim that this blocks platform-delivered ads.

#!/bin/sh
# Diagnostic only: this script never builds or packages a PS4 executable.
set -u

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
SDK_ROOT="${OO_PS4_TOOLCHAIN:-${ORBIS_SDK:-}}"
STRICT=0
[ "${1:-}" = "--strict" ] && STRICT=1

failures=0
printf '%s\n' "SmartTubePS4 PS4 toolchain diagnostic"
printf '%s\n' "Project: $ROOT"

if [ -z "$SDK_ROOT" ]; then
  echo "MISSING: set OO_PS4_TOOLCHAIN or ORBIS_SDK to your OpenOrbis toolchain root."
  failures=$((failures + 1))
else
  echo "Toolchain root: $SDK_ROOT"
  if [ ! -d "$SDK_ROOT" ]; then
    echo "MISSING: toolchain directory does not exist."
    failures=$((failures + 1))
  else
    found_compiler=0
    for candidate in \
      "$SDK_ROOT/bin/orbis-clang" \
      "$SDK_ROOT/bin/orbis-clang++" \
      "$SDK_ROOT/toolchain/bin/orbis-clang" \
      "$SDK_ROOT/toolchain/bin/orbis-clang++"; do
      if [ -x "$candidate" ]; then
        echo "FOUND: compiler $candidate"
        found_compiler=1
        break
      fi
    done
    if [ "$found_compiler" -eq 0 ]; then
      echo "MISSING: could not locate an executable orbis-clang/orbis-clang++ in common toolchain paths."
      failures=$((failures + 1))
    fi

    found_packager=0
    for candidate in \
      "$SDK_ROOT/bin/create-fself" \
      "$SDK_ROOT/bin/create-pkg" \
      "$SDK_ROOT/toolchain/bin/create-fself" \
      "$SDK_ROOT/toolchain/bin/create-pkg"; do
      if [ -x "$candidate" ]; then
        echo "FOUND: packaging tool $candidate"
        found_packager=1
      fi
    done
    if [ "$found_packager" -eq 0 ]; then
      echo "NOTE: no create-fself/create-pkg executable found in common paths; packaging tools may be elsewhere or not installed."
    fi
  fi
fi

echo "PENDING: native PS4 app entrypoint and GPU renderer are not implemented."
echo "UNVERIFIED: OpenOrbis Pad controller adapter source exists but has not been cross-compiled or tested on hardware."
echo "PENDING: verified PS4 AV-player operation table and real media decoder/output."
echo "NOT BUILT: SELF, GP4, or PKG."
if [ "$failures" -ne 0 ]; then
  echo "RESULT: toolchain prerequisites not verified."
  [ "$STRICT" -eq 1 ] && exit 1
  exit 0
fi
echo "RESULT: basic compiler-path check passed only; this does not prove SDK/API or firmware compatibility."

#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
CC="${CC:-cc}"
TMP="${TMPDIR:-/tmp}/stps4-v06-tests-$$"
trap 'rm -f "$TMP-sponsor" "$TMP-state" "$TMP-ui" "$TMP-render" "$TMP-media" "$TMP-runtime" "$TMP-sbclient" "$TMP-sbjson" "$TMP-sbhttps" "$TMP-sbpipeline" "$TMP-sbplayer" "$TMP-playersession" "$TMP-avadapter" "$TMP-ds4" "$TMP-graphics" "$TMP-viewport" "$TMP-smoke"' EXIT
CFLAGS="-std=c11 -Wall -Wextra -Werror -I$ROOT/native/include"
"$CC" $CFLAGS "$ROOT/native/src/sponsorblock.c" "$ROOT/native/tests/test_sponsorblock.c" -o "$TMP-sponsor"; "$TMP-sponsor"
"$CC" $CFLAGS "$ROOT/native/src/app_state.c" "$ROOT/native/src/controller_map.c" "$ROOT/native/tests/test_app_state.c" -o "$TMP-state"; "$TMP-state"
"$CC" $CFLAGS "$ROOT/native/src/app_state.c" "$ROOT/native/src/ui_model.c" "$ROOT/native/src/settings.c" "$ROOT/native/tests/test_ui_settings.c" -o "$TMP-ui"; "$TMP-ui"
"$CC" $CFLAGS "$ROOT/native/src/ui_model.c" "$ROOT/native/src/app_state.c" "$ROOT/native/src/render_commands.c" "$ROOT/native/src/platform_adapter.c" "$ROOT/native/tests/test_render.c" -o "$TMP-render"; "$TMP-render"
"$CC" $CFLAGS "$ROOT/native/src/media_backend.c" "$ROOT/native/tests/test_media_backend.c" -lm -o "$TMP-media"; "$TMP-media"
"$CC" $CFLAGS "$ROOT/native/src/app_state.c" "$ROOT/native/src/controller_map.c" "$ROOT/native/src/ui_model.c" "$ROOT/native/src/render_commands.c" "$ROOT/native/src/platform_adapter.c" "$ROOT/native/src/runtime.c" "$ROOT/native/tests/test_runtime.c" -o "$TMP-runtime"; "$TMP-runtime"
"$CC" $CFLAGS "$ROOT/native/src/sponsorblock.c" "$ROOT/native/src/sponsorblock_client.c" "$ROOT/native/tests/test_sponsorblock_client.c" -o "$TMP-sbclient"; "$TMP-sbclient"
"$CC" $CFLAGS "$ROOT/native/src/sponsorblock.c" "$ROOT/native/src/sponsorblock_json.c" "$ROOT/native/tests/test_sponsorblock_json.c" -o "$TMP-sbjson"; "$TMP-sbjson"
if command -v pkg-config >/dev/null 2>&1 && pkg-config --exists libcurl openssl; then
  HTTPS_CFLAGS="$(pkg-config --cflags libcurl openssl)"
  HTTPS_LIBS="$(pkg-config --libs libcurl openssl)"
  # shellcheck disable=SC2086
  "$CC" $CFLAGS $HTTPS_CFLAGS "$ROOT/native/src/sponsorblock.c" "$ROOT/native/src/sponsorblock_https.c" "$ROOT/native/tests/test_sponsorblock_https.c" $HTTPS_LIBS -o "$TMP-sbhttps"
  "$TMP-sbhttps"
else
  echo 'SKIP: HTTPS transport tests require libcurl and OpenSSL development packages.'
fi
"$CC" $CFLAGS "$ROOT/native/src/sponsorblock.c" "$ROOT/native/src/sponsorblock_json.c" "$ROOT/native/src/sponsorblock_https.c" "$ROOT/native/src/sponsorblock_pipeline.c" "$ROOT/native/tests/test_sponsorblock_pipeline.c" $(pkg-config --cflags --libs libcurl openssl 2>/dev/null || true) -lm -o "$TMP-sbpipeline"
"$TMP-sbpipeline"
"$CC" $CFLAGS "$ROOT/native/src/sponsorblock.c" "$ROOT/native/src/sponsorblock_https.c" "$ROOT/native/src/sponsorblock_json.c" "$ROOT/native/src/sponsorblock_pipeline.c" "$ROOT/native/src/media_backend.c" "$ROOT/native/src/sponsorblock_player.c" "$ROOT/native/tests/test_sponsorblock_player.c" $(pkg-config --cflags --libs libcurl openssl 2>/dev/null || true) -lm -o "$TMP-sbplayer"
"$TMP-sbplayer"
"$CC" $CFLAGS "$ROOT/native/src/media_backend.c" "$ROOT/native/src/player_session.c" "$ROOT/native/tests/test_player_session.c" -lm -o "$TMP-playersession"
"$TMP-playersession"
"$CC" $CFLAGS "$ROOT/native/src/media_backend.c" "$ROOT/native/src/player_session.c" "$ROOT/native/src/avplayer_adapter.c" "$ROOT/native/tests/test_avplayer_adapter.c" -lm -o "$TMP-avadapter"
"$TMP-avadapter"
"$CC" $CFLAGS "$ROOT/native/src/controller_map.c" "$ROOT/native/src/ds4_input.c" "$ROOT/native/tests/test_ds4_input.c" -o "$TMP-ds4"
"$TMP-ds4"
"$CC" $CFLAGS "$ROOT/native/src/platform_adapter.c" "$ROOT/native/src/graphics_backend.c" "$ROOT/native/tests/test_graphics_backend.c" -o "$TMP-graphics"
"$TMP-graphics"
"$CC" $CFLAGS "$ROOT/native/src/graphics_viewport.c" "$ROOT/native/tests/test_graphics_viewport.c" -lm -o "$TMP-viewport"
"$TMP-viewport"
"$CC" $CFLAGS "$ROOT/native/src/app_state.c" "$ROOT/native/src/main.c" -o "$TMP-smoke"
"$TMP-smoke"
echo 'All available host tests and application smoke build passed.'   

#include "graphics_viewport.h"
#include <math.h>
#include <string.h>

int st_graphics_viewport_init(st_graphics_viewport_t *v, uint32_t width, uint32_t height) {
    if (!v || width == 0 || height == 0) return -1;
    float sx = (float)width / ST_RENDER_WIDTH;
    float sy = (float)height / ST_RENDER_HEIGHT;
    float scale = sx < sy ? sx : sy;
    if (!isfinite(scale) || scale <= 0.0f) return -1;
    v->scale = scale;
    v->output_width = width;
    v->output_height = height;
    v->offset_x = ((float)width - ST_RENDER_WIDTH * scale) * 0.5f;
    v->offset_y = ((float)height - ST_RENDER_HEIGHT * scale) * 0.5f;
    return 0;
}

int st_graphics_viewport_map(const st_graphics_viewport_t *v,
                             const st_draw_command_t *in,
                             st_draw_command_t *out) {
    float expected_scale, expected_x, expected_y;
    float mapped_x, mapped_y, mapped_w, mapped_h;
    if (!v || !in || !out || v->output_width == 0 || v->output_height == 0 ||
        !isfinite(v->scale) || v->scale <= 0.0f ||
        !isfinite(v->offset_x) || !isfinite(v->offset_y) ||
        !isfinite(in->x) || !isfinite(in->y) || !isfinite(in->w) || !isfinite(in->h) ||
        in->kind < ST_DRAW_RECT || in->kind > ST_DRAW_OUTLINE_RECT ||
        in->x < 0.0f || in->y < 0.0f || in->w < 0.0f || in->h < 0.0f ||
        in->x + in->w > ST_RENDER_WIDTH || in->y + in->h > ST_RENDER_HEIGHT ||
        memchr(in->text, '\0', sizeof(in->text)) == NULL) return -1;

    expected_scale = ((float)v->output_width / ST_RENDER_WIDTH <
                      (float)v->output_height / ST_RENDER_HEIGHT)
                         ? (float)v->output_width / ST_RENDER_WIDTH
                         : (float)v->output_height / ST_RENDER_HEIGHT;
    expected_x = ((float)v->output_width - ST_RENDER_WIDTH * expected_scale) * 0.5f;
    expected_y = ((float)v->output_height - ST_RENDER_HEIGHT * expected_scale) * 0.5f;
    if (!isfinite(expected_scale) || expected_scale <= 0.0f ||
        fabsf(v->scale - expected_scale) > 0.0001f ||
        fabsf(v->offset_x - expected_x) > 0.01f ||
        fabsf(v->offset_y - expected_y) > 0.01f) return -1;

    mapped_x = v->offset_x + in->x * v->scale;
    mapped_y = v->offset_y + in->y * v->scale;
    mapped_w = in->w * v->scale;
    mapped_h = in->h * v->scale;
    if (!isfinite(mapped_x) || !isfinite(mapped_y) ||
        !isfinite(mapped_w) || !isfinite(mapped_h) ||
        mapped_x < 0.0f || mapped_y < 0.0f ||
        mapped_x + mapped_w > (float)v->output_width + 0.01f ||
        mapped_y + mapped_h > (float)v->output_height + 0.01f) return -1;

    *out = *in;
    out->x = mapped_x;
    out->y = mapped_y;
    out->w = mapped_w;
    out->h = mapped_h;
    return 0;
}

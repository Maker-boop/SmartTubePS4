#include "player_session.h"
#include <math.h>
#include <stddef.h>
#include <string.h>

static bool has_scheme(const char *uri, const char *scheme) {
    size_t n = strlen(scheme);
    return strncmp(uri, scheme, n) == 0;
}

bool st_player_uri_is_supported(const char *uri) {
    if (!uri || !uri[0]) return false;
    return has_scheme(uri, "file://") || has_scheme(uri, "http://") ||
           has_scheme(uri, "https://");
}

void st_player_session_init(st_player_session_t *s, st_media_backend_t *backend) {
    if (!s) return;
    memset(s, 0, sizeof(*s));
    s->backend = backend;
    s->state = ST_PLAYER_IDLE;
}

static st_player_result_t backend_error(st_player_session_t *s) {
    s->state = ST_PLAYER_ERROR;
    return ST_PLAYER_ERR_BACKEND;
}

st_player_result_t st_player_session_open(st_player_session_t *s, const char *uri) {
    st_media_result_t rc;
    if (!s || !s->backend || !uri) return ST_PLAYER_ERR_ARGUMENT;
    if (!st_player_uri_is_supported(uri)) return ST_PLAYER_ERR_URI;
    if (!st_media_backend_is_valid(s->backend)) return ST_PLAYER_ERR_BACKEND;
    if (s->state != ST_PLAYER_IDLE) st_player_session_close(s);
    rc = st_media_open(s->backend, uri);
    if (rc != ST_MEDIA_OK) return backend_error(s);
    s->position_seconds = 0.0;
    s->duration_seconds = 0.0;
    s->state = ST_PLAYER_OPEN;
    s->media_generation++;
    return ST_PLAYER_OK;
}

st_player_result_t st_player_session_play(st_player_session_t *s) {
    if (!s || !s->backend) return ST_PLAYER_ERR_ARGUMENT;
    if (s->state != ST_PLAYER_OPEN && s->state != ST_PLAYER_PAUSED &&
        s->state != ST_PLAYER_PLAYING) return ST_PLAYER_ERR_STATE;
    if (s->backend->play(s->backend->context) != ST_MEDIA_OK) return backend_error(s);
    s->state = ST_PLAYER_PLAYING;
    return ST_PLAYER_OK;
}

st_player_result_t st_player_session_pause(st_player_session_t *s) {
    if (!s || !s->backend) return ST_PLAYER_ERR_ARGUMENT;
    if (s->state != ST_PLAYER_PLAYING && s->state != ST_PLAYER_PAUSED)
        return ST_PLAYER_ERR_STATE;
    if (s->backend->pause(s->backend->context) != ST_MEDIA_OK) return backend_error(s);
    s->state = ST_PLAYER_PAUSED;
    return ST_PLAYER_OK;
}

st_player_result_t st_player_session_seek(st_player_session_t *s, double seconds) {
    if (!s || !s->backend || !isfinite(seconds) || seconds < 0.0)
        return ST_PLAYER_ERR_ARGUMENT;
    if (s->state != ST_PLAYER_OPEN && s->state != ST_PLAYER_PLAYING &&
        s->state != ST_PLAYER_PAUSED && s->state != ST_PLAYER_ENDED) return ST_PLAYER_ERR_STATE;
    if (s->duration_seconds > 0.0 && seconds > s->duration_seconds)
        seconds = s->duration_seconds;
    if (st_media_seek(s->backend, seconds) != ST_MEDIA_OK) return backend_error(s);
    s->position_seconds = seconds;
    if (s->state == ST_PLAYER_ENDED) s->state = ST_PLAYER_PAUSED;
    return ST_PLAYER_OK;
}

st_player_result_t st_player_session_update(st_player_session_t *s) {
    double position = 0.0, duration = 0.0;
    st_media_result_t rc;
    if (!s || !s->backend) return ST_PLAYER_ERR_ARGUMENT;
    if (s->state != ST_PLAYER_OPEN && s->state != ST_PLAYER_PLAYING &&
        s->state != ST_PLAYER_PAUSED) return ST_PLAYER_ERR_STATE;
    rc = s->backend->get_position(s->backend->context, &position, &duration);
    if (rc != ST_MEDIA_OK) return backend_error(s);
    if (!isfinite(position) || !isfinite(duration) || position < 0.0 ||
        duration <= 0.0 || position > duration + 1.0)
        return ST_PLAYER_ERR_POSITION;
    if (position > duration) position = duration;
    s->position_seconds = position;
    s->duration_seconds = duration;
    if (s->state == ST_PLAYER_PLAYING && position >= duration - 0.05)
        s->state = ST_PLAYER_ENDED;
    return ST_PLAYER_OK;
}

void st_player_session_close(st_player_session_t *s) {
    if (!s) return;
    if (s->backend && st_media_backend_is_valid(s->backend) &&
        s->state != ST_PLAYER_IDLE)
        s->backend->close(s->backend->context);
    s->position_seconds = 0.0;
    s->duration_seconds = 0.0;
    s->state = ST_PLAYER_IDLE;
}

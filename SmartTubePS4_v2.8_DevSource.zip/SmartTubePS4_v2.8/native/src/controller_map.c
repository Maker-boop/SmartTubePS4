#include "controller_map.h"
st_action_t st_controller_map(st_pad_button_t b) {
    switch(b) {
    case ST_PAD_UP: return ST_ACT_UP; case ST_PAD_DOWN: return ST_ACT_DOWN;
    case ST_PAD_LEFT: return ST_ACT_LEFT; case ST_PAD_RIGHT: return ST_ACT_RIGHT;
    case ST_PAD_CROSS: return ST_ACT_CONFIRM; case ST_PAD_CIRCLE: return ST_ACT_BACK;
    case ST_PAD_TRIANGLE: return ST_ACT_PLAY_PAUSE;
    case ST_PAD_L1: return ST_ACT_SEEK_BACK; case ST_PAD_R1: return ST_ACT_SEEK_FORWARD;
    case ST_PAD_OPTIONS: return ST_ACT_EXIT;
    default: return ST_ACT_NONE;
    }
}

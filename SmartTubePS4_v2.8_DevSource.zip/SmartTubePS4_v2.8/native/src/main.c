#include <stdio.h>
#include "app_config.h"
#include "app_state.h"

/* Portable state-machine smoke entry point. Replace with PS4 SDK startup,
 * renderer, controller polling, networking, and a licensed media backend. */
int main(void) {
    st_app_state_t state;
    st_app_init(&state);
    printf("%s %s\n", APP_TITLE, APP_VERSION);
    printf("Platform target: %s\n", APP_TARGET_PLATFORM);
    printf("UI state initialized (screen=%d, menu_items=%u).\n",
           (int)state.screen, state.item_count);
    puts("This host executable is not a PS4 SELF or installable PKG.");
    return 0;
}

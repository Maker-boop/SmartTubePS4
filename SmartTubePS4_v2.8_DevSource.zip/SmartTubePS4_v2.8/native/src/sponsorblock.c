#include "sponsorblock.h"

static int finite_nonnegative(double value) {
    /* NaN fails both comparisons; infinities are rejected by upper-bound checks. */
    return value >= 0.0 && value < 1.0e12;
}

int sb_segment_is_valid(const sb_segment_t *segment, double duration_seconds) {
    if (!segment || !finite_nonnegative(duration_seconds) || duration_seconds <= 0.0)
        return 0;
    if (segment->category < 0 || segment->category >= SB_CATEGORY_COUNT)
        return 0;
    if (!finite_nonnegative(segment->start_seconds) ||
        !finite_nonnegative(segment->end_seconds))
        return 0;
    if (segment->end_seconds <= segment->start_seconds)
        return 0;
    if (segment->start_seconds >= duration_seconds ||
        segment->end_seconds > duration_seconds + 0.25)
        return 0;
    return 1;
}

int sb_should_skip(const sb_segment_t *segment,
                   const sb_preferences_t *preferences,
                   double duration_seconds) {
    if (!preferences || !sb_segment_is_valid(segment, duration_seconds))
        return 0;
    if (segment->is_mandatory)
        return 1;
    if (!preferences->enabled[segment->category])
        return 0;
    if ((segment->end_seconds - segment->start_seconds) <
        preferences->minimum_segment_seconds)
        return 0;
    return 1;
}

int sb_find_next_segment(const sb_segment_t *segments,
                         size_t segment_count,
                         const sb_preferences_t *preferences,
                         double duration_seconds,
                         double current_seconds,
                         double lookahead_seconds,
                         sb_segment_t *out_segment) {
    size_t i;
    int found = 0;
    sb_segment_t best;
    double window_end;

    if (!segments || !preferences || !out_segment ||
        !finite_nonnegative(current_seconds) ||
        !finite_nonnegative(lookahead_seconds))
        return 0;

    window_end = current_seconds + lookahead_seconds;
    if (window_end < current_seconds)
        return 0;

    for (i = 0; i < segment_count; ++i) {
        const sb_segment_t *candidate = &segments[i];
        if (!sb_should_skip(candidate, preferences, duration_seconds))
            continue;
        if (candidate->end_seconds < current_seconds ||
            candidate->start_seconds > window_end)
            continue;
        if (!found || candidate->start_seconds < best.start_seconds) {
            best = *candidate;
            found = 1;
        }
    }

    if (found)
        *out_segment = best;
    return found;
}

const char *sb_category_api_name(sb_category_t category) {
    static const char *names[SB_CATEGORY_COUNT] = {
        "sponsor", "selfpromo", "interaction", "intro",
        "outro", "preview", "filler", "music_offtopic"
    };
    if (category < 0 || category >= SB_CATEGORY_COUNT)
        return "unknown";
    return names[category];
}

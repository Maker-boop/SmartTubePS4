#include "media_backend.h"
#include <math.h>
#include <stddef.h>
bool st_media_backend_is_valid(const st_media_backend_t *b) {
    return b && b->open && b->play && b->pause && b->seek &&
           b->get_position && b->close;
}
st_media_result_t st_media_open(st_media_backend_t *b, const char *uri) {
    if (!b || !uri || uri[0] == '\0') return ST_MEDIA_ERR_ARGUMENT;
    if (!st_media_backend_is_valid(b)) return ST_MEDIA_ERR_UNAVAILABLE;
    return b->open(b->context, uri);
}
st_media_result_t st_media_seek(st_media_backend_t *b, double seconds) {
    if (!b || !isfinite(seconds) || seconds < 0.0)
        return ST_MEDIA_ERR_ARGUMENT;
    if (!st_media_backend_is_valid(b)) return ST_MEDIA_ERR_UNAVAILABLE;
    return b->seek(b->context, seconds);
}

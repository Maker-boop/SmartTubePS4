#include "avplayer_adapter.h"
#include <math.h>
#include <string.h>

static st_media_result_t adapter_open(void *context, const char *uri) {
    st_avplayer_adapter_t *a = (st_avplayer_adapter_t *)context;
    if (!a || !uri || !uri[0]) return ST_MEDIA_ERR_ARGUMENT;
    if (a->source_open) a->ops.close_source(a->ops.context);
    a->source_open = false;
    if (!a->ops.open_source(a->ops.context, uri)) return ST_MEDIA_ERR_FAILED;
    a->source_open = true;
    return ST_MEDIA_OK;
}

static st_media_result_t adapter_play(void *context) {
    st_avplayer_adapter_t *a = (st_avplayer_adapter_t *)context;
    if (!a || !a->source_open) return ST_MEDIA_ERR_UNAVAILABLE;
    return a->ops.start(a->ops.context) ? ST_MEDIA_OK : ST_MEDIA_ERR_FAILED;
}

static st_media_result_t adapter_pause(void *context) {
    st_avplayer_adapter_t *a = (st_avplayer_adapter_t *)context;
    if (!a || !a->source_open) return ST_MEDIA_ERR_UNAVAILABLE;
    return a->ops.pause(a->ops.context) ? ST_MEDIA_OK : ST_MEDIA_ERR_FAILED;
}

static st_media_result_t adapter_seek(void *context, double seconds) {
    st_avplayer_adapter_t *a = (st_avplayer_adapter_t *)context;
    if (!a || !isfinite(seconds) || seconds < 0.0) return ST_MEDIA_ERR_ARGUMENT;
    if (!a->source_open) return ST_MEDIA_ERR_UNAVAILABLE;
    return a->ops.seek_seconds(a->ops.context, seconds) ? ST_MEDIA_OK : ST_MEDIA_ERR_FAILED;
}

static st_media_result_t adapter_position(void *context, double *position,
                                          double *duration) {
    st_avplayer_adapter_t *a = (st_avplayer_adapter_t *)context;
    if (!a || !position || !duration) return ST_MEDIA_ERR_ARGUMENT;
    if (!a->source_open) return ST_MEDIA_ERR_UNAVAILABLE;
    if (!a->ops.query_time(a->ops.context, position, duration))
        return ST_MEDIA_ERR_FAILED;
    if (!isfinite(*position) || !isfinite(*duration) || *position < 0.0 ||
        *duration <= 0.0 || *position > *duration + 1.0)
        return ST_MEDIA_ERR_FAILED;
    if (*position > *duration) *position = *duration;
    return ST_MEDIA_OK;
}

static void adapter_close(void *context) {
    st_avplayer_adapter_t *a = (st_avplayer_adapter_t *)context;
    if (!a || !a->source_open) return;
    a->ops.close_source(a->ops.context);
    a->source_open = false;
}

bool st_avplayer_adapter_init(st_avplayer_adapter_t *a,
                              const st_avplayer_ops_t *ops,
                              st_media_backend_t *backend) {
    if (!a || !ops || !backend || !ops->open_source || !ops->start ||
        !ops->pause || !ops->seek_seconds || !ops->query_time ||
        !ops->close_source) return false;
    memset(a, 0, sizeof(*a));
    a->ops = *ops;
    backend->context = a;
    backend->open = adapter_open;
    backend->play = adapter_play;
    backend->pause = adapter_pause;
    backend->seek = adapter_seek;
    backend->get_position = adapter_position;
    backend->close = adapter_close;
    return true;
}

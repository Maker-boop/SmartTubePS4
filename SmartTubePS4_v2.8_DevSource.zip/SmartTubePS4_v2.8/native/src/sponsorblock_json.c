#include "sponsorblock_json.h"
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

#define JSON_MAX_DEPTH 32

typedef struct { const char *p; } parser_t;
static void ws(parser_t *p) { while (*p->p && isspace((unsigned char)*p->p)) ++p->p; }
static int take(parser_t *p, char c) { ws(p); if (*p->p != c) return 0; ++p->p; return 1; }
static int string_value(parser_t *p, char *out, size_t cap) {
    size_t n = 0; ws(p); if (*p->p++ != '"') return 0;
    while (*p->p && *p->p != '"') {
        unsigned char c = (unsigned char)*p->p++;
        if (c == '\\') {
            c = (unsigned char)*p->p++;
            if (!c) return 0;
            if (c == 'u') { int i; for (i=0;i<4;i++) if (!isxdigit((unsigned char)*p->p++)) return 0; c='?'; }
            else if (c=='"' || c=='\\' || c=='/') { }
            else if (c=='b') c='\b'; else if (c=='f') c='\f'; else if (c=='n') c='\n'; else if (c=='r') c='\r'; else if (c=='t') c='\t'; else return 0;
        }
        if (out && n + 1 < cap) out[n] = (char)c;
        ++n;
    }
    if (*p->p++ != '"' || (out && n >= cap)) return 0;
    if (out) out[n] = '\0';
    return 1;
}
static int number_value(parser_t *p, double *v) {
    char *end; ws(p); *v = strtod(p->p, &end); if (end == p->p) return 0;
    if (*v != *v || *v > 1.0e12 || *v < -1.0e12) return 0;
    p->p = end; return 1;
}
static int skip_value(parser_t *p, int depth);
static int skip_array(parser_t *p, int depth) {
    if (depth > JSON_MAX_DEPTH || !take(p,'[')) return 0;
    ws(p);
    if (take(p,']')) return 1;
    do { if (!skip_value(p,depth+1)) return 0; ws(p); if (take(p,']')) return 1; } while (take(p,',')); return 0;
}
static int skip_object(parser_t *p, int depth) {
    char key[128]; if (depth > JSON_MAX_DEPTH || !take(p,'{')) return 0; ws(p); if (take(p,'}')) return 1;
    do { if (!string_value(p,key,sizeof key) || !take(p,':') || !skip_value(p,depth+1)) return 0; ws(p); if (take(p,'}')) return 1; } while (take(p,',')); return 0;
}
static int skip_value(parser_t *p, int depth) {
    ws(p); if (depth > JSON_MAX_DEPTH) return 0;
    if (*p->p=='{') return skip_object(p,depth);
    if (*p->p=='[') return skip_array(p,depth);
    if (*p->p=='"') return string_value(p,NULL,0);
    if (*p->p=='-' || isdigit((unsigned char)*p->p)) { double d; return number_value(p,&d); }
    if (!strncmp(p->p,"true",4)) { p->p+=4; return 1; }
    if (!strncmp(p->p,"false",5)) { p->p+=5; return 1; }
    if (!strncmp(p->p,"null",4)) { p->p+=4; return 1; }
    return 0;
}
static int category_from_name(const char *s, sb_category_t *out) {
    int i; for (i=0;i<SB_CATEGORY_COUNT;i++) if (!strcmp(s,sb_category_api_name((sb_category_t)i))) { *out=(sb_category_t)i; return 1; } return 0;
}
static int parse_segment_pair(parser_t *p, double *a, double *b) {
    if (!take(p,'[') || !number_value(p,a) || !take(p,',') || !number_value(p,b) || !take(p,']')) return 0;
    return 1;
}
static int parse_item(parser_t *p, double duration, sb_segment_t *out, int *emit) {
    char key[128], value[128]; sb_category_t category=SB_CATEGORY_COUNT; double a=0,b=0; int have_pair=0;
    *emit=0; if (!take(p,'{')) return 0; ws(p); if (take(p,'}')) return 1;
    for (;;) {
        if (!string_value(p,key,sizeof key) || !take(p,':')) return 0;
        if (!strcmp(key,"category")) { if (!string_value(p,value,sizeof value)) return 0; (void)category_from_name(value,&category); }
        else if (!strcmp(key,"segment")) { if (!parse_segment_pair(p,&a,&b)) return 0; have_pair=1; }
        else if (!skip_value(p,1)) return 0;
        ws(p);
        if (take(p,'}')) break;
        if (!take(p,',')) return 0;
    }
    if (category != SB_CATEGORY_COUNT && have_pair) {
        out->start_seconds=a; out->end_seconds=b; out->category=category; out->is_mandatory=0;
        if (sb_segment_is_valid(out,duration)) *emit=1;
    }
    return 1;
}

sb_json_result_t sb_parse_skip_segments_json(const char *json, double duration,
        sb_segment_t *out, size_t capacity, size_t *count) {
    parser_t p; size_t n=0; int emit;
    if (!json || !out || !count || capacity==0 || duration<=0.0) return SB_JSON_ERR_ARGUMENT;
    *count=0; p.p=json; if (!take(&p,'[')) return SB_JSON_ERR_MALFORMED;
    ws(&p);
    if (!take(&p,']')) {
        for (;;) {
            if (!parse_item(&p,duration,&out[n<capacity?n:capacity-1],&emit)) return SB_JSON_ERR_MALFORMED;
            if (emit) { if (n>=capacity) return SB_JSON_ERR_CAPACITY; ++n; }
            ws(&p);
            if (take(&p,']')) break;
            if (!take(&p,',')) return SB_JSON_ERR_MALFORMED;
        }
    }
    ws(&p); if (*p.p!='\0') return SB_JSON_ERR_MALFORMED;
    *count=n; return SB_JSON_OK;
}

static int parse_segments_array(parser_t *p, double duration,
                                sb_segment_t *out, size_t capacity,
                                size_t *count) {
    size_t n = 0;
    int emit;
    if (!take(p, '[')) return 0;
    ws(p);
    if (take(p, ']')) { *count = 0; return 1; }
    for (;;) {
        sb_segment_t item;
        if (!parse_item(p, duration, &item, &emit)) return 0;
        if (emit) {
            if (n >= capacity) return -1;
            out[n++] = item;
        }
        ws(p);
        if (take(p, ']')) break;
        if (!take(p, ',')) return 0;
    }
    *count = n;
    return 1;
}

sb_json_result_t sb_parse_kanon_response_json(const char *json,
        const char *video_id, double duration, sb_segment_t *out,
        size_t capacity, size_t *count) {
    parser_t p;
    char key[128];
    size_t n = 0;
    int found = 0, parsed;
    if (!json || !video_id || !out || !capacity || !count ||
        strlen(video_id) != 11 || duration <= 0.0)
        return SB_JSON_ERR_ARGUMENT;
    *count = 0;
    p.p = json;
    if (!take(&p, '{')) return SB_JSON_ERR_MALFORMED;
    ws(&p);
    if (!take(&p, '}')) {
        for (;;) {
            if (!string_value(&p, key, sizeof key) || !take(&p, ':'))
                return SB_JSON_ERR_MALFORMED;
            if (strcmp(key, video_id) == 0) {
                if (found) return SB_JSON_ERR_MALFORMED;
                parsed = parse_segments_array(&p, duration, out, capacity, &n);
                if (parsed == -1) return SB_JSON_ERR_CAPACITY;
                if (!parsed) return SB_JSON_ERR_MALFORMED;
                found = 1;
            } else if (!skip_value(&p, 1)) {
                return SB_JSON_ERR_MALFORMED;
            }
            ws(&p);
            if (take(&p, '}')) break;
            if (!take(&p, ',')) return SB_JSON_ERR_MALFORMED;
        }
    }
    ws(&p);
    if (*p.p != '\0') return SB_JSON_ERR_MALFORMED;
    if (found) *count = n;
    return SB_JSON_OK;
}

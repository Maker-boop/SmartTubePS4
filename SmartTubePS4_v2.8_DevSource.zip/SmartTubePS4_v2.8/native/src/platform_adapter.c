#include "platform_adapter.h"
#include <math.h>
#include <stddef.h>
#include <string.h>

static int valid_command(const st_draw_command_t *c) {
    if (!c) return 0;
    if (c->kind < ST_DRAW_RECT || c->kind > ST_DRAW_OUTLINE_RECT) return 0;
    if (!isfinite(c->x) || !isfinite(c->y) ||
        !isfinite(c->w) || !isfinite(c->h)) return 0;
    if (c->x < 0.0f || c->y < 0.0f || c->w < 0.0f || c->h < 0.0f) return 0;
    if (c->x + c->w > ST_RENDER_WIDTH || c->y + c->h > ST_RENDER_HEIGHT) return 0;
    if (memchr(c->text, '\0', sizeof(c->text)) == NULL) return 0;
    return 1;
}

int st_platform_present(const st_platform_adapter_t *p, const st_draw_list_t *l) {
    if (!p || !l || !p->begin_frame || !p->draw || !p->end_frame) return -1;
    if (l->count > ST_RENDER_MAX_COMMANDS) return -5;
    /* Validate the entire frame before opening a backend frame. This prevents
       malformed command lists from partially drawing or reading out of bounds. */
    for (unsigned i = 0; i < l->count; ++i) {
        if (!valid_command(&l->commands[i])) return -6;
    }
    if (p->begin_frame(p->context) != 0) return -2;
    for (unsigned i = 0; i < l->count; ++i) {
        if (p->draw(p->context, &l->commands[i]) != 0) {
            (void)p->end_frame(p->context);
            return -3;
        }
    }
    return p->end_frame(p->context) == 0 ? 0 : -4;
}

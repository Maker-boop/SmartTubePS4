#include "sponsorblock_client.h"
#include <stdio.h>
#include <string.h>

static int is_video_id_char(char c) {
    return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
           (c >= '0' && c <= '9') || c == '_' || c == '-';
}

sb_client_result_t sb_build_skip_segments_url(
    const char *video_id,
    const sb_preferences_t *preferences,
    char *out_url,
    size_t out_capacity) {
    size_t i;
    size_t used;
    int selected = 0;
    int written;

    if (!video_id || !preferences || !out_url || out_capacity == 0)
        return SB_CLIENT_ERR_ARGUMENT;
    out_url[0] = '\0';
    if (strlen(video_id) != SB_VIDEO_ID_LENGTH)
        return SB_CLIENT_ERR_VIDEO_ID;
    for (i = 0; i < SB_VIDEO_ID_LENGTH; ++i) {
        if (!is_video_id_char(video_id[i]))
            return SB_CLIENT_ERR_VIDEO_ID;
    }

    written = snprintf(out_url, out_capacity, "%s?videoID=%s&actionType=skip&service=YouTube",
                       SB_API_BASE_URL, video_id);
    if (written < 0 || (size_t)written >= out_capacity) {
        out_url[0] = '\0';
        return SB_CLIENT_ERR_BUFFER;
    }
    used = (size_t)written;

    for (i = 0; i < SB_CATEGORY_COUNT; ++i) {
        const char *name;
        if (!preferences->enabled[i])
            continue;
        name = sb_category_api_name((sb_category_t)i);
        written = snprintf(out_url + used, out_capacity - used,
                           "&category=%s", name);
        if (written < 0 || (size_t)written >= out_capacity - used) {
            out_url[0] = '\0';
            return SB_CLIENT_ERR_BUFFER;
        }
        used += (size_t)written;
        selected++;
    }
    if (!selected) {
        out_url[0] = '\0';
        return SB_CLIENT_ERR_NO_CATEGORIES;
    }
    return SB_CLIENT_OK;
}

#include "app_state.h"

static void clamp_focus(st_app_state_t *s) {
    if (s->item_count == 0) s->focus_index = 0;
    else if (s->focus_index >= s->item_count) s->focus_index = s->item_count - 1;
}
void st_app_init(st_app_state_t *s) {
    if (!s) return;
    s->screen=ST_SCREEN_HOME; s->focus_index=0; s->item_count=5;
    s->playing=false; s->has_video=false; s->should_exit=false; s->shutdown_notified=false; s->position_seconds=0; s->duration_seconds=0;
}
void st_app_set_items(st_app_state_t *s, unsigned count) {
    if (!s) return;
    s->item_count=count;
    clamp_focus(s);
}
void st_app_dispatch(st_app_state_t *s, st_action_t a) {
    if (!s) return;
    switch (a) {
    case ST_ACT_UP: if (s->focus_index>0) s->focus_index--; break;
    case ST_ACT_DOWN: if (s->item_count && s->focus_index+1<s->item_count) s->focus_index++; break;
    case ST_ACT_LEFT: if (s->screen==ST_SCREEN_PLAYER && s->has_video) { s->position_seconds-=10; if(s->position_seconds<0)s->position_seconds=0; } break;
    case ST_ACT_RIGHT: if (s->screen==ST_SCREEN_PLAYER && s->has_video) { s->position_seconds+=10; if(s->duration_seconds>0 && s->position_seconds>s->duration_seconds)s->position_seconds=s->duration_seconds; } break;
    case ST_ACT_PLAY_PAUSE: if (s->has_video) s->playing=!s->playing; break;
    case ST_ACT_SEEK_BACK: if (s->screen==ST_SCREEN_PLAYER && s->has_video) { s->position_seconds-=30; if(s->position_seconds<0)s->position_seconds=0; } break;
    case ST_ACT_SEEK_FORWARD: if (s->screen==ST_SCREEN_PLAYER && s->has_video) { s->position_seconds+=30; if(s->duration_seconds>0 && s->position_seconds>s->duration_seconds)s->position_seconds=s->duration_seconds; } break;
    case ST_ACT_EXIT: s->should_exit=true; break;
    case ST_ACT_BACK: if (s->screen==ST_SCREEN_PLAYER) s->screen=ST_SCREEN_HOME; else if(s->screen!=ST_SCREEN_HOME) s->screen=ST_SCREEN_HOME; break;
    case ST_ACT_CONFIRM:
        if (s->screen==ST_SCREEN_HOME) {
            static const st_screen_t destinations[]={
                ST_SCREEN_SEARCH, ST_SCREEN_LIBRARY, ST_SCREEN_SETTINGS,
                ST_SCREEN_PLAYER, ST_SCREEN_ABOUT
            };
            if (s->focus_index < 5) {
                st_screen_t destination = destinations[s->focus_index];
                if (destination != ST_SCREEN_PLAYER || s->has_video)
                    s->screen = destination;
            }
        }
        break;
    default: break;
    }
    clamp_focus(s);
}

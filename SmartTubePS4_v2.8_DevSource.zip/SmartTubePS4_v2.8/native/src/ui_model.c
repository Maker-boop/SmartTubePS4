#include "ui_model.h"
#include <stdio.h>
#include <string.h>
static void add(st_ui_model_t *m, const char *label, const char *detail) {
    if (m->count >= ST_UI_MAX_ITEMS) return;
    st_ui_item_t *i=&m->items[m->count++];
    snprintf(i->label,sizeof(i->label),"%s",label);
    snprintf(i->detail,sizeof(i->detail),"%s",detail);
}
void st_ui_build_model(const st_app_state_t *s, st_ui_model_t *m) {
    if (!m) return;
    memset(m,0,sizeof(*m));
    if (!s) { snprintf(m->title,sizeof(m->title),"SmartTube PS4"); return; }
    m->screen=s->screen;
    switch(s->screen) {
    case ST_SCREEN_HOME:
        snprintf(m->title,sizeof(m->title),"SmartTube PS4");
        snprintf(m->subtitle,sizeof(m->subtitle),"Your videos, organized for the big screen");
        add(m,"Search","Find videos from configured sources");
        add(m,"Library","Favorites and watch history");
        add(m,"Settings","Playback and sponsor-skip preferences");
        add(m,"Continue watching","Resume supported playback");
        add(m,"About","Build and compatibility information"); break;
    case ST_SCREEN_SEARCH:
        snprintf(m->title,sizeof(m->title),"Search");
        snprintf(m->subtitle,sizeof(m->subtitle),"Search provider adapter is not connected yet");
        add(m,"Search field","Text entry adapter required");
        add(m,"Recent searches","No saved searches yet");
        add(m,"Back to Home","Return to main menu"); break;
    case ST_SCREEN_LIBRARY:
        snprintf(m->title,sizeof(m->title),"Your Library");
        snprintf(m->subtitle,sizeof(m->subtitle),"Local library storage adapter is not connected");
        add(m,"Favorites","Saved videos will appear here");
        add(m,"Watch history","Recently played videos will appear here");
        add(m,"Back to Home","Return to main menu"); break;
    case ST_SCREEN_SETTINGS:
        snprintf(m->title,sizeof(m->title),"Settings");
        snprintf(m->subtitle,sizeof(m->subtitle),"SponsorBlock skips creator-marked segments when seeking is supported");
        add(m,"Sponsor skipping","Configure categories in config/sponsorblock.json");
        add(m,"Playback","Quality and player backend settings");
        add(m,"Privacy","Local history and data controls");
        add(m,"Back to Home","Return to main menu"); break;
    case ST_SCREEN_ABOUT:
        snprintf(m->title,sizeof(m->title),"About SmartTube PS4");
        snprintf(m->subtitle,sizeof(m->subtitle),"Native homebrew development build · v2.2");
        add(m,"Platform target","PS4 firmware target is user-reported; not validated");
        add(m,"Playback status","No media backend is connected");
        add(m,"SponsorBlock","Core policy exists; network/seek adapter remains pending");
        add(m,"Back to Home","Return to main menu"); break;
    case ST_SCREEN_PLAYER:
        snprintf(m->title,sizeof(m->title),"Now Playing");
        snprintf(m->subtitle,sizeof(m->subtitle),"%s",s->playing?"Playing":"Paused");
        add(m,"Play / Pause","Triangle");
        add(m,"Seek backward","L1 · 30 seconds");
        add(m,"Seek forward","R1 · 30 seconds");
        add(m,"Back to Home","Circle"); break;
    }
    m->focus=s->focus_index;
    if (m->count && m->focus>=m->count) m->focus=m->count-1;
    for (unsigned n=0;n<m->count;n++) m->items[n].selected=(n==m->focus);
}

#include "render_commands.h"
#include <stdio.h>
#include <string.h>

static void add(st_draw_list_t *l, st_draw_kind_t k, float x, float y,
                float w, float h, uint32_t c, const char *t) {
    if (!l || l->count >= ST_RENDER_MAX_COMMANDS) return;
    st_draw_command_t *d = &l->commands[l->count++];
    d->kind = k; d->x = x; d->y = y; d->w = w; d->h = h; d->color = c;
    if (t) { snprintf(d->text, sizeof(d->text), "%s", t); }
    else d->text[0] = '\0';
}

static void add_text(st_draw_list_t *l, float x, float y, float w, float h,
                     uint32_t color, const char *text) {
    add(l, ST_DRAW_TEXT, x, y, w, h, color, text);
}

static void add_header(st_draw_list_t *o, const st_ui_model_t *m) {
    add(o, ST_DRAW_RECT, 0, 0, ST_RENDER_WIDTH, 112, ST_COLOR_PANEL, NULL);
    add_text(o, 64, 32, 420, 48, ST_COLOR_WHITE, "SMARTTUBE");
    add_text(o, 470, 39, 700, 36, ST_COLOR_MUTED,
             m->screen == ST_SCREEN_HOME ? "HOME     SEARCH     LIBRARY     SETTINGS" : "HOME     SEARCH     LIBRARY     SETTINGS");
    add(o, ST_DRAW_LINE, 64, 110, 1792, 2, ST_COLOR_BLUE, NULL);
}

static void add_home(st_draw_list_t *o, const st_ui_model_t *m) {
    add_text(o, 64, 150, 1100, 58, ST_COLOR_WHITE, "Welcome to SmartTube");
    add_text(o, 64, 212, 1300, 42, ST_COLOR_MUTED,
             "Your videos, organized for the big screen");

    /* Featured area is intentionally an interface placeholder until a legal,
       working content provider and thumbnail pipeline are connected. */
    add(o, ST_DRAW_RECT, 64, 286, 1792, 220, ST_COLOR_PANEL_ALT, NULL);
    add(o, ST_DRAW_OUTLINE_RECT, 64, 286, 1792, 220, ST_COLOR_FOCUS_EDGE, NULL);
    add_text(o, 104, 330, 1000, 52, ST_COLOR_WHITE, "YOUR VIDEO DESTINATION");
    add_text(o, 104, 390, 1200, 42, ST_COLOR_MUTED,
             "Connect a supported video source to start watching");

    for (unsigned i = 0; i < m->count && i < ST_UI_MAX_ITEMS; ++i) {
        unsigned col = i % 3u;
        unsigned row = i / 3u;
        float x = 64.0f + (float)col * 600.0f;
        float y = 548.0f + (float)row * 190.0f;
        uint32_t fill = m->items[i].selected ? ST_COLOR_FOCUS : ST_COLOR_PANEL;
        add(o, ST_DRAW_RECT, x, y, 560, 154, fill, NULL);
        if (m->items[i].selected)
            add(o, ST_DRAW_OUTLINE_RECT, x, y, 560, 154, ST_COLOR_FOCUS_EDGE, NULL);
        add_text(o, x + 28, y + 30, 500, 42, ST_COLOR_WHITE, m->items[i].label);
        add_text(o, x + 28, y + 86, 500, 36, ST_COLOR_MUTED, m->items[i].detail);
    }
}

static void add_standard_screen(st_draw_list_t *o, const st_ui_model_t *m) {
    add_text(o, 64, 158, 1200, 60, ST_COLOR_WHITE, m->title);
    add_text(o, 64, 222, 1500, 42, ST_COLOR_MUTED, m->subtitle);
    for (unsigned i = 0; i < m->count && i < ST_UI_MAX_ITEMS; ++i) {
        float y = 318.0f + (float)i * 88.0f;
        uint32_t fill = m->items[i].selected ? ST_COLOR_FOCUS : ST_COLOR_PANEL;
        add(o, ST_DRAW_RECT, 64, y, 1792, 68, fill, NULL);
        if (m->items[i].selected)
            add(o, ST_DRAW_OUTLINE_RECT, 64, y, 1792, 68, ST_COLOR_FOCUS_EDGE, NULL);
        add_text(o, 96, y + 16, 960, 38, ST_COLOR_WHITE, m->items[i].label);
        add_text(o, 1120, y + 16, 700, 38, ST_COLOR_MUTED, m->items[i].detail);
    }
}

void st_render_build(const st_ui_model_t *m, st_draw_list_t *o) {
    if (!o) return;
    memset(o, 0, sizeof(*o));
    if (!m) return;

    add(o, ST_DRAW_RECT, 0, 0, ST_RENDER_WIDTH, ST_RENDER_HEIGHT, ST_COLOR_BG, NULL);
    add_header(o, m);
    if (m->screen == ST_SCREEN_HOME) add_home(o, m);
    else add_standard_screen(o, m);

    add(o, ST_DRAW_LINE, 64, 1000, 1792, 2, ST_COLOR_BLUE, NULL);
    add_text(o, 64, 1020, 1700, 32, ST_COLOR_MUTED,
             "X Select       O Back       OPTIONS Exit       L1/R1 Seek");
}

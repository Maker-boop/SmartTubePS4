#include "ds4_input.h"
#include <string.h>

typedef struct {
    uint32_t mask;
    st_pad_button_t button;
} st_ds4_binding_t;

static const st_ds4_binding_t bindings[] = {
    { ST_DS4_UP, ST_PAD_UP },
    { ST_DS4_DOWN, ST_PAD_DOWN },
    { ST_DS4_LEFT, ST_PAD_LEFT },
    { ST_DS4_RIGHT, ST_PAD_RIGHT },
    { ST_DS4_CROSS, ST_PAD_CROSS },
    { ST_DS4_CIRCLE, ST_PAD_CIRCLE },
    { ST_DS4_TRIANGLE, ST_PAD_TRIANGLE },
    { ST_DS4_L1, ST_PAD_L1 },
    { ST_DS4_R1, ST_PAD_R1 },
    { ST_DS4_OPTIONS, ST_PAD_OPTIONS }
};

void st_ds4_input_init(st_ds4_input_t *input) {
    if (input) memset(input, 0, sizeof(*input));
}

void st_ds4_input_update(st_ds4_input_t *input, uint32_t buttons) {
    size_t i;
    if (!input) return;

    input->event_count = 0;
    input->event_index = 0;
    for (i = 0; i < sizeof(bindings) / sizeof(bindings[0]); ++i) {
        const uint32_t mask = bindings[i].mask;
        if ((buttons & mask) && !(input->previous_buttons & mask) &&
            input->event_count < ST_DS4_EVENT_CAPACITY) {
            input->events[input->event_count++] = bindings[i].button;
        }
    }
    input->previous_buttons = buttons;
}

int st_ds4_input_poll(st_ds4_input_t *input, st_pad_button_t *button) {
    if (!input || !button) return -1;
    if (input->event_index >= input->event_count) return 0;
    *button = input->events[input->event_index++];
    return 1;
}

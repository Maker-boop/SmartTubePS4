#include "sponsorblock_player.h"
#include <math.h>

void sb_player_state_reset(sb_player_state_t *state) {
    if (!state) return;
    state->last_skipped_start = 0.0;
    state->last_skipped_end = 0.0;
    state->has_last_skipped = 0;
}

sb_player_result_t sb_player_tick(st_media_backend_t *backend,
    const sb_pipeline_result_t *segments, const sb_preferences_t *preferences,
    double duration_seconds, double trigger_window_seconds,
    sb_player_state_t *state, sb_segment_t *skipped_segment) {
    double position = 0.0, duration = 0.0;
    sb_segment_t candidate;
    st_media_result_t media_rc;
    if (skipped_segment) {
        skipped_segment->start_seconds = 0.0;
        skipped_segment->end_seconds = 0.0;
        skipped_segment->category = 0;
        skipped_segment->is_mandatory = 0;
    }
    if (!backend || !segments || !preferences || !state ||
        !isfinite(duration_seconds) || duration_seconds <= 0.0 ||
        !isfinite(trigger_window_seconds) || trigger_window_seconds < 0.0 ||
        segments->count > segments->capacity ||
        (segments->count && !segments->segments))
        return SB_PLAYER_ERR_ARGUMENT;
    if (!preferences->automatic_skip) return SB_PLAYER_NO_ACTION;
    if (!st_media_backend_is_valid(backend)) return SB_PLAYER_ERR_BACKEND;
    media_rc = backend->get_position(backend->context, &position, &duration);
    if (media_rc != ST_MEDIA_OK) return SB_PLAYER_ERR_POSITION;
    if (!isfinite(position) || position < 0.0 || !isfinite(duration) || duration <= 0.0)
        return SB_PLAYER_ERR_POSITION;
    if (duration > duration_seconds + 1.0 || duration < duration_seconds - 1.0)
        duration_seconds = duration;
    /* A user-initiated rewind should make previously skipped segments eligible
     * again. This also handles replaying a portion of the same video. */
    if (state->has_last_skipped &&
        position < state->last_skipped_start - 0.25) {
        sb_player_state_reset(state);
    }
    if (!sb_pipeline_next_skip(segments, preferences, duration_seconds,
        position, trigger_window_seconds, &candidate))
        return SB_PLAYER_NO_ACTION;
    if (position + trigger_window_seconds < candidate.start_seconds ||
        position > candidate.end_seconds)
        return SB_PLAYER_NO_ACTION;
    if (state->has_last_skipped &&
        fabs(state->last_skipped_start - candidate.start_seconds) < 0.001 &&
        fabs(state->last_skipped_end - candidate.end_seconds) < 0.001)
        return SB_PLAYER_NO_ACTION;
    if (backend->seek(backend->context, candidate.end_seconds) != ST_MEDIA_OK)
        return SB_PLAYER_ERR_SEEK;
    state->last_skipped_start = candidate.start_seconds;
    state->last_skipped_end = candidate.end_seconds;
    state->has_last_skipped = 1;
    if (skipped_segment) *skipped_segment = candidate;
    return SB_PLAYER_SEEKED;
}

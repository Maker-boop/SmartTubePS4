#include "graphics_backend.h"
#include <string.h>

static int valid_dimensions(uint32_t width, uint32_t height) {
    return width >= ST_GRAPHICS_MIN_WIDTH && width <= ST_GRAPHICS_MAX_WIDTH &&
           height >= ST_GRAPHICS_MIN_HEIGHT && height <= ST_GRAPHICS_MAX_HEIGHT;
}

int st_graphics_device_init(st_graphics_device_t *device,
                            const st_graphics_ops_t *ops,
                            uint32_t width, uint32_t height) {
    if (!device || !ops || !ops->initialize || !ops->begin_frame ||
        !ops->draw || !ops->end_frame || !ops->shutdown) return -1;
    if (!valid_dimensions(width, height)) return -2;
    if (device->initialized) return -3;

    /* The backend owns partial-init cleanup too: shutdown must be safe after
       initialize reports failure. Do not publish a half-ready device. */
    if (ops->initialize(ops->context, width, height) != 0) {
        ops->shutdown(ops->context);
        return -4;
    }
    device->ops = *ops;
    device->width = width;
    device->height = height;
    device->initialized = true;
    return 0;
}

int st_graphics_device_present(st_graphics_device_t *device,
                               const st_draw_list_t *list) {
    if (!device || !device->initialized) return -1;
    st_platform_adapter_t adapter;
    memset(&adapter, 0, sizeof(adapter));
    adapter.context = device->ops.context;
    adapter.begin_frame = device->ops.begin_frame;
    adapter.draw = device->ops.draw;
    adapter.end_frame = device->ops.end_frame;
    return st_platform_present(&adapter, list);
}

void st_graphics_device_shutdown(st_graphics_device_t *device) {
    if (!device || !device->initialized) return;
    device->ops.shutdown(device->ops.context);
    memset(&device->ops, 0, sizeof(device->ops));
    device->width = 0;
    device->height = 0;
    device->initialized = false;
}

#include "sponsorblock_https.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <curl/curl.h>
#include <openssl/sha.h>

typedef struct { char *data; size_t cap, used; int overflow; } response_sink_t;
static int valid_id(const char *id) {
    size_t i;
    if (!id || strlen(id) != SB_VIDEO_ID_LENGTH) return 0;
    for (i=0;i<SB_VIDEO_ID_LENGTH;i++) {
        unsigned char c=(unsigned char)id[i];
        if (!((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'||c=='-')) return 0;
    }
    return 1;
}
static size_t receive_body(char *ptr, size_t size, size_t nmemb, void *userdata) {
    response_sink_t *s=(response_sink_t *)userdata; size_t n;
    if (size && nmemb > (size_t)-1 / size) return 0;
    n=size*nmemb;
    if (n >= s->cap - s->used) { s->overflow=1; return 0; }
    memcpy(s->data+s->used,ptr,n); s->used+=n; s->data[s->used]='\0'; return n;
}
sb_https_result_t sb_build_private_skip_url(const char *video_id,
    const sb_preferences_t *preferences, char *out_url, size_t cap) {
    unsigned char digest[SHA256_DIGEST_LENGTH]; char hex[5]; size_t i, used; int selected=0, n;
    static const char digits[]="0123456789abcdef";
    if (!video_id || !preferences || !out_url || !cap) return SB_HTTPS_ERR_ARGUMENT;
    out_url[0]='\0'; if (!valid_id(video_id)) return SB_HTTPS_ERR_ARGUMENT;
    if (!SHA256((const unsigned char *)video_id,SB_VIDEO_ID_LENGTH,digest)) return SB_HTTPS_ERR_CRYPTO;
    for (i=0;i<2;i++) { hex[i*2]=digits[digest[i]>>4]; hex[i*2+1]=digits[digest[i]&15]; } hex[4]='\0';
    n=snprintf(out_url,cap,"https://sponsor.ajay.app/api/skipSegments/%s?service=YouTube",hex);
    if (n<0 || (size_t)n>=cap) { out_url[0]='\0'; return SB_HTTPS_ERR_BUFFER; } used=(size_t)n;
    for (i=0;i<SB_CATEGORY_COUNT;i++) if (preferences->enabled[i]) {
        const char *cat=sb_category_api_name((sb_category_t)i);
        n=snprintf(out_url+used,cap-used,"&category=%s",cat);
        if (n<0 || (size_t)n>=cap-used) { out_url[0]='\0'; return SB_HTTPS_ERR_BUFFER; }
        used+=(size_t)n; selected++;
    }
    if (!selected) { out_url[0]='\0'; return SB_HTTPS_ERR_URL; }
    return SB_HTTPS_OK;
}
sb_https_result_t sb_https_get(const char *url, char *response, size_t cap,
    size_t *length, long *status) {
    CURL *curl; CURLcode rc; response_sink_t sink; long code=0;
    if (!url || !response || cap<2 || !length || !status) return SB_HTTPS_ERR_ARGUMENT;
    *length=0; *status=0; response[0]='\0';
    if (strncmp(url,"https://sponsor.ajay.app/",sizeof("https://sponsor.ajay.app/")-1)!=0) return SB_HTTPS_ERR_URL;
    if (curl_global_init(CURL_GLOBAL_DEFAULT)!=CURLE_OK) return SB_HTTPS_ERR_NETWORK;
    curl=curl_easy_init(); if (!curl) { curl_global_cleanup(); return SB_HTTPS_ERR_NETWORK; }
    sink.data=response; sink.cap=cap; sink.used=0; sink.overflow=0;
    curl_easy_setopt(curl,CURLOPT_URL,url);
    curl_easy_setopt(curl,CURLOPT_PROTOCOLS_STR,"https");
    curl_easy_setopt(curl,CURLOPT_SSL_VERIFYPEER,1L);
    curl_easy_setopt(curl,CURLOPT_SSL_VERIFYHOST,2L);
    curl_easy_setopt(curl,CURLOPT_FOLLOWLOCATION,0L);
    curl_easy_setopt(curl,CURLOPT_CONNECTTIMEOUT,10L);
    curl_easy_setopt(curl,CURLOPT_TIMEOUT,20L);
    curl_easy_setopt(curl,CURLOPT_USERAGENT,"SmartTubePS4-Dev/1.1");
    curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,receive_body);
    curl_easy_setopt(curl,CURLOPT_WRITEDATA,&sink);
    rc=curl_easy_perform(curl); curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&code);
    curl_easy_cleanup(curl); curl_global_cleanup();
    *length=sink.used; *status=code;
    if (sink.overflow) return SB_HTTPS_ERR_BUFFER;
    if (rc!=CURLE_OK) return SB_HTTPS_ERR_NETWORK;
    return code==200 ? SB_HTTPS_OK : SB_HTTPS_ERR_HTTP;
}

#include "sponsorblock_pipeline.h"
#include <math.h>
#include <string.h>

static sb_https_result_t default_get(void *ctx, const char *url, char *body,
    size_t cap, size_t *length, long *status) {
    (void)ctx;
    return sb_https_get(url, body, cap, length, status);
}

sb_https_result_t sb_pipeline_fetch_segments(const char *video_id,
    const sb_preferences_t *preferences, double duration_seconds,
    char *response_buffer, size_t response_capacity,
    sb_pipeline_result_t *result, sb_pipeline_get_fn get_fn, void *get_context) {
    char url[1024]; size_t response_length = 0; sb_https_result_t rc;
    if (!video_id || !preferences || !response_buffer || response_capacity < 2 ||
        !result || !result->segments || result->capacity == 0 ||
        !isfinite(duration_seconds) || duration_seconds <= 0.0)
        return SB_HTTPS_ERR_ARGUMENT;
    result->count = 0; result->http_status = 0; response_buffer[0] = '\0';
    if (!get_fn) get_fn = default_get;
    rc = sb_build_private_skip_url(video_id, preferences, url, sizeof url);
    if (rc != SB_HTTPS_OK) return rc;
    rc = get_fn(get_context, url, response_buffer, response_capacity,
        &response_length, &result->http_status);
    if (rc != SB_HTTPS_OK) return rc;
    if (response_length >= response_capacity) return SB_HTTPS_ERR_BUFFER;
    response_buffer[response_length] = '\0';
    if (sb_parse_kanon_response_json(response_buffer, video_id, duration_seconds,
        result->segments, result->capacity, &result->count) != SB_JSON_OK) {
        result->count = 0;
        return SB_HTTPS_ERR_HTTP; /* response was received but was not valid API JSON */
    }
    return SB_HTTPS_OK;
}

int sb_pipeline_next_skip(const sb_pipeline_result_t *result,
    const sb_preferences_t *preferences, double duration_seconds,
    double current_seconds, double lookahead_seconds, sb_segment_t *out_segment) {
    if (!result || !preferences || !result->segments || !out_segment ||
        result->count > result->capacity) return 0;
    return sb_find_next_segment(result->segments, result->count, preferences,
        duration_seconds, current_seconds, lookahead_seconds, out_segment);
}

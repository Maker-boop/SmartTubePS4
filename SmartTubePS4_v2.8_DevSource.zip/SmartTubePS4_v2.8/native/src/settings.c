#include "settings.h"
#include <stdio.h>
#include <string.h>

void st_settings_defaults(st_settings_t *s) {
    if (!s) return;
    *s = (st_settings_t){true, true, true, false, false, false, false, false};
}

bool st_settings_save(const st_settings_t *s, const char *path) {
    if (!s || !path) return false;
    FILE *f = fopen(path, "w");
    if (!f) return false;
    int ok = fprintf(f,
        "sponsor_skip_enabled=%d\nskip_sponsor=%d\nskip_self_promo=%d\n"
        "skip_intro=%d\nskip_outro=%d\nskip_interaction=%d\n"
        "skip_music_offtopic=%d\nskip_preview=%d\n",
        s->sponsor_skip_enabled, s->skip_sponsor, s->skip_self_promo,
        s->skip_intro, s->skip_outro, s->skip_interaction,
        s->skip_music_offtopic, s->skip_preview) >= 0;
    if (fclose(f) != 0) ok = 0;
    return ok != 0;
}

static bool parse_bool(const char *value, bool *out) {
    if (!strcmp(value, "1") || !strcmp(value, "true")) {
        *out = true;
        return true;
    }
    if (!strcmp(value, "0") || !strcmp(value, "false")) {
        *out = false;
        return true;
    }
    return false;
}

bool st_settings_load(st_settings_t *s, const char *path) {
    if (!s || !path) return false;
    FILE *f = fopen(path, "r");
    if (!f) return false;
    st_settings_t tmp;
    st_settings_defaults(&tmp);
    char line[128];
    bool valid = true;
    while (fgets(line, sizeof(line), f)) {
        char *eq = strchr(line, '=');
        if (!eq) continue;
        *eq++ = '\0';
        eq[strcspn(eq, "\r\n")] = 0;
        bool *field = NULL;
        if (!strcmp(line, "sponsor_skip_enabled")) field = &tmp.sponsor_skip_enabled;
        else if (!strcmp(line, "skip_sponsor")) field = &tmp.skip_sponsor;
        else if (!strcmp(line, "skip_self_promo")) field = &tmp.skip_self_promo;
        else if (!strcmp(line, "skip_intro")) field = &tmp.skip_intro;
        else if (!strcmp(line, "skip_outro")) field = &tmp.skip_outro;
        else if (!strcmp(line, "skip_interaction")) field = &tmp.skip_interaction;
        else if (!strcmp(line, "skip_music_offtopic")) field = &tmp.skip_music_offtopic;
        else if (!strcmp(line, "skip_preview")) field = &tmp.skip_preview;
        if (field && !parse_bool(eq, field)) valid = false;
    }
    if (ferror(f)) valid = false;
    fclose(f);
    if (valid) *s = tmp;
    return valid;
}

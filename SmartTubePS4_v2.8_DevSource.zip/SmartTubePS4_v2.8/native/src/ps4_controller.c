#include "ps4_controller.h"

#include <orbis/Pad.h>
#include <string.h>

bool st_ps4_controller_open(st_ps4_controller_t *controller,
                            int32_t user_id, int32_t controller_type,
                            int32_t controller_index) {
    int32_t handle;
    if (!controller) return false;
    memset(controller, 0, sizeof(*controller));
    controller->handle = -1;

    if (scePadInit() != 0) return false;
    handle = scePadOpen(user_id, controller_type, controller_index, NULL);
    if (handle < 0) return false;

    controller->handle = handle;
    controller->initialized = true;
    st_ds4_input_init(&controller->input);
    return true;
}

int st_ps4_controller_poll(void *context, st_pad_button_t *button) {
    st_ps4_controller_t *controller = (st_ps4_controller_t *)context;
    OrbisPadData data;
    int result;
    if (!controller || !button || !controller->initialized) return -1;

    result = st_ds4_input_poll(&controller->input, button);
    if (result != 0) return result;

    memset(&data, 0, sizeof(data));
    if (scePadReadState(controller->handle, &data) != 0) return -1;
    st_ds4_input_update(&controller->input, data.buttons);
    return st_ds4_input_poll(&controller->input, button);
}

void st_ps4_controller_close(st_ps4_controller_t *controller) {
    if (!controller || !controller->initialized) return;
    (void)scePadClose(controller->handle);
    controller->handle = -1;
    controller->initialized = false;
    st_ds4_input_init(&controller->input);
}

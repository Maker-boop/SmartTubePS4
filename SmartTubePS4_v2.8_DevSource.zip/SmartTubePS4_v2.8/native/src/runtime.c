#include "runtime.h"
#include "ui_model.h"
#include "render_commands.h"

st_runtime_result_t st_runtime_frame(st_app_state_t *state,
                                     const st_platform_adapter_t *platform) {
    st_pad_button_t button;
    st_ui_model_t model;
    st_draw_list_t draw_list;
    int input_result;
    unsigned processed = 0;

    if (!state || !platform || !platform->poll_button)
        return ST_RUNTIME_ERR_ARGUMENT;

    if (state->should_exit) {
        if (!state->shutdown_notified) {
            if (platform->shutdown)
                platform->shutdown(platform->context);
            state->shutdown_notified = true;
        }
        return ST_RUNTIME_EXIT_REQUESTED;
    }

    while (processed < ST_RUNTIME_MAX_INPUT_EVENTS_PER_FRAME) {
        input_result = platform->poll_button(platform->context, &button);
        if (input_result < 0)
            return ST_RUNTIME_ERR_INPUT;
        if (input_result == 0)
            break;
        st_app_dispatch(state, st_controller_map(button));
        processed++;
        if (state->should_exit)
            break;
    }

    if (state->should_exit) {
        if (!state->shutdown_notified) {
            if (platform->shutdown)
                platform->shutdown(platform->context);
            state->shutdown_notified = true;
        }
        return ST_RUNTIME_EXIT_REQUESTED;
    }

    st_ui_build_model(state, &model);
    st_app_set_items(state, model.count);
    /* Rebuild so the selected item reflects the clamped application focus. */
    st_ui_build_model(state, &model);
    st_render_build(&model, &draw_list);
    if (st_platform_present(platform, &draw_list) != 0)
        return ST_RUNTIME_ERR_PRESENT;
    return ST_RUNTIME_OK;
}

#ifndef STPS4_SPONSORBLOCK_CLIENT_H
#define STPS4_SPONSORBLOCK_CLIENT_H
#include <stddef.h>
#include "sponsorblock.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SB_VIDEO_ID_LENGTH 11
#define SB_API_BASE_URL "https://sponsor.ajay.app/api/skipSegments"

typedef enum {
    SB_CLIENT_OK = 0,
    SB_CLIENT_ERR_ARGUMENT = -1,
    SB_CLIENT_ERR_VIDEO_ID = -2,
    SB_CLIENT_ERR_NO_CATEGORIES = -3,
    SB_CLIENT_ERR_BUFFER = -4
} sb_client_result_t;

/* Build a GET URL for the official read-only skipSegments API.
 * Categories are sent as repeated `category` query parameters, as documented
 * by SponsorBlock. The caller supplies the HTTPS transport and response parser.
 */
sb_client_result_t sb_build_skip_segments_url(
    const char *video_id,
    const sb_preferences_t *preferences,
    char *out_url,
    size_t out_capacity);

#ifdef __cplusplus
}
#endif
#endif

#ifndef STPS4_SPONSORBLOCK_PIPELINE_H
#define STPS4_SPONSORBLOCK_PIPELINE_H
#include <stddef.h>
#include "sponsorblock_https.h"
#include "sponsorblock_json.h"

typedef sb_https_result_t (*sb_pipeline_get_fn)(void *context, const char *url,
    char *response, size_t response_capacity, size_t *response_length, long *http_status);

typedef struct {
    sb_segment_t *segments;
    size_t capacity;
    size_t count;
    long http_status;
} sb_pipeline_result_t;

/* Fetch and parse one k-anonymity response. The transport is injectable so
 * host tests can exercise the full request->response->segment path offline. */
sb_https_result_t sb_pipeline_fetch_segments(const char *video_id,
    const sb_preferences_t *preferences, double duration_seconds,
    char *response_buffer, size_t response_capacity,
    sb_pipeline_result_t *result, sb_pipeline_get_fn get_fn, void *get_context);

/* Return the next eligible segment in the configured look-ahead window. */
int sb_pipeline_next_skip(const sb_pipeline_result_t *result,
    const sb_preferences_t *preferences, double duration_seconds,
    double current_seconds, double lookahead_seconds, sb_segment_t *out_segment);
#endif

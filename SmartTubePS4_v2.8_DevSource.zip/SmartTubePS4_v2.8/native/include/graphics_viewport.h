#ifndef STPS4_GRAPHICS_VIEWPORT_H
#define STPS4_GRAPHICS_VIEWPORT_H
#include <stdint.h>
#include "render_commands.h"
typedef struct { float scale, offset_x, offset_y; uint32_t output_width, output_height; } st_graphics_viewport_t;
#define ST_GRAPHICS_VIEWPORT_INIT {0}
/* Aspect-fit the fixed 1920x1080 logical canvas into an output surface.
 * Initialize with st_graphics_viewport_init; do not hand-edit its fields. */
int st_graphics_viewport_init(st_graphics_viewport_t *viewport, uint32_t width, uint32_t height);
int st_graphics_viewport_map(const st_graphics_viewport_t *viewport,
                             const st_draw_command_t *logical,
                             st_draw_command_t *output);
#endif

#ifndef STPS4_GRAPHICS_BACKEND_H
#define STPS4_GRAPHICS_BACKEND_H

#include <stdbool.h>
#include <stdint.h>
#include "platform_adapter.h"

#define ST_GRAPHICS_MIN_WIDTH 320u
#define ST_GRAPHICS_MIN_HEIGHT 200u
#define ST_GRAPHICS_MAX_WIDTH 3840u
#define ST_GRAPHICS_MAX_HEIGHT 2160u

typedef struct {
    void *context;
    int (*initialize)(void *context, uint32_t width, uint32_t height);
    int (*begin_frame)(void *context);
    int (*draw)(void *context, const st_draw_command_t *command);
    int (*end_frame)(void *context);
    void (*shutdown)(void *context);
} st_graphics_ops_t;

#define ST_GRAPHICS_DEVICE_INIT {0}

typedef struct {
    st_graphics_ops_t ops;
    uint32_t width;
    uint32_t height;
    bool initialized;
} st_graphics_device_t;

/* Initialize with ST_GRAPHICS_DEVICE_INIT before the first init. The caller
 * must not pass an uninitialized object.
 * Backend shutdown must tolerate being called after a failed initialize, so
 * partially acquired platform resources can be released.
 * Creates a graphics-device lifecycle around a platform-supplied backend.
 * Draw commands remain in the logical 1920x1080 coordinate space; the backend
 * is responsible for mapping that space to the requested output dimensions.
 * This module contains no PS4 SDK/GPU calls. */
int st_graphics_device_init(st_graphics_device_t *device,
                            const st_graphics_ops_t *ops,
                            uint32_t width, uint32_t height);
int st_graphics_device_present(st_graphics_device_t *device,
                               const st_draw_list_t *list);
void st_graphics_device_shutdown(st_graphics_device_t *device);

#endif

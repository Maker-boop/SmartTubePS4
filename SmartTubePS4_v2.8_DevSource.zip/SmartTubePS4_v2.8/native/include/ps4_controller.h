#ifndef STPS4_PS4_CONTROLLER_H
#define STPS4_PS4_CONTROLLER_H

#include "platform_adapter.h"
#include "ds4_input.h"
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    int32_t handle;
    bool initialized;
    st_ds4_input_t input;
} st_ps4_controller_t;

/* Call from the PS4 application after the user service is ready. The caller
 * supplies the active user ID and the Pad library controller type/index. */
bool st_ps4_controller_open(st_ps4_controller_t *controller,
                            int32_t user_id, int32_t controller_type,
                            int32_t controller_index);
int st_ps4_controller_poll(void *context, st_pad_button_t *button);
void st_ps4_controller_close(st_ps4_controller_t *controller);

#endif

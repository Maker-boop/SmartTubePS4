#ifndef STPS4_SPONSORBLOCK_HTTPS_H
#define STPS4_SPONSORBLOCK_HTTPS_H
#include <stddef.h>
#include "sponsorblock.h"
#include "sponsorblock_client.h"

typedef enum {
    SB_HTTPS_OK = 0,
    SB_HTTPS_ERR_ARGUMENT = -10,
    SB_HTTPS_ERR_URL = -11,
    SB_HTTPS_ERR_NETWORK = -12,
    SB_HTTPS_ERR_HTTP = -13,
    SB_HTTPS_ERR_BUFFER = -14,
    SB_HTTPS_ERR_CRYPTO = -15
} sb_https_result_t;

/* Build the privacy-preserving k-anonymity URL. Only the first four SHA-256
 * hex characters of the video ID are disclosed to SponsorBlock. */
sb_https_result_t sb_build_private_skip_url(const char *video_id,
    const sb_preferences_t *preferences, char *out_url, size_t out_capacity);

/* libcurl/OpenSSL implementation. TLS peer and host verification are enabled.
 * A 404 is reported as SB_HTTPS_ERR_HTTP with http_status set to 404. */
sb_https_result_t sb_https_get(const char *url, char *response,
    size_t response_capacity, size_t *response_length, long *http_status);
#endif

#ifndef STPS4_SPONSORBLOCK_JSON_H
#define STPS4_SPONSORBLOCK_JSON_H
#include <stddef.h>
#include "sponsorblock.h"

typedef enum {
    SB_JSON_OK = 0,
    SB_JSON_ERR_ARGUMENT = -1,
    SB_JSON_ERR_MALFORMED = -2,
    SB_JSON_ERR_CAPACITY = -3
} sb_json_result_t;

/* Parse SponsorBlock skipSegments JSON into bounded native segments.
 * Unknown fields are ignored. Every emitted segment is validated against duration.
 * On any parse/capacity error, *out_count is set to zero.
 */
sb_json_result_t sb_parse_skip_segments_json(const char *json,
                                              double duration_seconds,
                                              sb_segment_t *out_segments,
                                              size_t out_capacity,
                                              size_t *out_count);
#endif

/* Parse the k-anonymity response object and select only the exact video ID key.
 * The response maps video IDs to skipSegments arrays. Other IDs are ignored.
 * On error or no match, *out_count is zero; no partial results are returned.
 */
sb_json_result_t sb_parse_kanon_response_json(const char *json,
                                               const char *video_id,
                                               double duration_seconds,
                                               sb_segment_t *out_segments,
                                               size_t out_capacity,
                                               size_t *out_count);

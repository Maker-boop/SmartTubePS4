#ifndef SMARTTUBE_SPONSORBLOCK_H
#define SMARTTUBE_SPONSORBLOCK_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    SB_CATEGORY_SPONSOR = 0,
    SB_CATEGORY_SELF_PROMO,
    SB_CATEGORY_INTERACTION,
    SB_CATEGORY_INTRO,
    SB_CATEGORY_OUTRO,
    SB_CATEGORY_PREVIEW,
    SB_CATEGORY_FILLER,
    SB_CATEGORY_OFF_TOPIC_MUSIC,
    SB_CATEGORY_COUNT
} sb_category_t;

typedef struct {
    double start_seconds;
    double end_seconds;
    sb_category_t category;
    int is_mandatory;
} sb_segment_t;

typedef struct {
    int enabled[SB_CATEGORY_COUNT];
    int automatic_skip;
    double minimum_segment_seconds;
} sb_preferences_t;

/* Validates a segment before it reaches the playback seek adapter. */
int sb_segment_is_valid(const sb_segment_t *segment, double duration_seconds);

/* Returns non-zero when this segment should be skipped under the preferences. */
int sb_should_skip(const sb_segment_t *segment,
                   const sb_preferences_t *preferences,
                   double duration_seconds);

/* Finds the earliest eligible segment intersecting [current_seconds, lookahead_end].
 * Returns 1 and copies the segment to out_segment, or returns 0 if none is found.
 */
int sb_find_next_segment(const sb_segment_t *segments,
                         size_t segment_count,
                         const sb_preferences_t *preferences,
                         double duration_seconds,
                         double current_seconds,
                         double lookahead_seconds,
                         sb_segment_t *out_segment);

const char *sb_category_api_name(sb_category_t category);

#ifdef __cplusplus
}
#endif
#endif

#ifndef STPS4_RUNTIME_H
#define STPS4_RUNTIME_H
#include "app_state.h"
#include "platform_adapter.h"

#define ST_RUNTIME_MAX_INPUT_EVENTS_PER_FRAME 16u

typedef enum {
    ST_RUNTIME_OK = 0,
    ST_RUNTIME_ERR_ARGUMENT = -1,
    ST_RUNTIME_ERR_INPUT = -2,
    ST_RUNTIME_ERR_PRESENT = -3,
    ST_RUNTIME_EXIT_REQUESTED = 1
} st_runtime_result_t;

/* Drain up to ST_RUNTIME_MAX_INPUT_EVENTS_PER_FRAME controller events, then
 * build and present one frame. poll_button returns 1 when it writes a button,
 * 0 when no event is ready, and a negative value on platform input failure.
 * A hard per-frame cap prevents a busy input queue starving rendering.
 * On exit, optional platform shutdown is called once and no further frame is drawn.
 */
st_runtime_result_t st_runtime_frame(st_app_state_t *state,
                                     const st_platform_adapter_t *platform);
#endif

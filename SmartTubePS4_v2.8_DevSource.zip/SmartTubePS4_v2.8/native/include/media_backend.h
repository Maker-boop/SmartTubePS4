#ifndef STPS4_MEDIA_BACKEND_H
#define STPS4_MEDIA_BACKEND_H
#include <stdbool.h>
typedef enum {
    ST_MEDIA_OK = 0,
    ST_MEDIA_ERR_ARGUMENT = -1,
    ST_MEDIA_ERR_UNAVAILABLE = -2,
    ST_MEDIA_ERR_FAILED = -3
} st_media_result_t;
typedef struct {
    void *context;
    st_media_result_t (*open)(void *context, const char *uri);
    st_media_result_t (*play)(void *context);
    st_media_result_t (*pause)(void *context);
    st_media_result_t (*seek)(void *context, double seconds);
    st_media_result_t (*get_position)(void *context, double *seconds, double *duration);
    void (*close)(void *context);
} st_media_backend_t;
/* Validate required callbacks before exposing a backend to the UI. */
bool st_media_backend_is_valid(const st_media_backend_t *backend);
st_media_result_t st_media_open(st_media_backend_t *backend, const char *uri);
st_media_result_t st_media_seek(st_media_backend_t *backend, double seconds);
#endif

#ifndef STPS4_CONTROLLER_MAP_H
#define STPS4_CONTROLLER_MAP_H
#include "app_state.h"
typedef enum { ST_PAD_UP, ST_PAD_DOWN, ST_PAD_LEFT, ST_PAD_RIGHT, ST_PAD_CROSS, ST_PAD_CIRCLE, ST_PAD_TRIANGLE, ST_PAD_L1, ST_PAD_R1, ST_PAD_OPTIONS } st_pad_button_t;
st_action_t st_controller_map(st_pad_button_t button);
#endif

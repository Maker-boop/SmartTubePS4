#ifndef STPS4_PLATFORM_ADAPTER_H
#define STPS4_PLATFORM_ADAPTER_H
#include "render_commands.h"
#include "controller_map.h"
typedef struct {
    void *context;
    int (*begin_frame)(void *context);
    int (*draw)(void *context, const st_draw_command_t *command);
    int (*end_frame)(void *context);
    int (*poll_button)(void *context, st_pad_button_t *button);
    void (*shutdown)(void *context);
} st_platform_adapter_t;
/* Platform contract: a real PS4 adapter must implement these callbacks with
 * supported PS4 SDK/OpenOrbis APIs. This repository does not contain that adapter.
 * Return codes: -1 bad arguments/callbacks, -2 begin-frame failure,
 * -3 draw failure (end_frame is attempted), -4 end-frame failure,
 * -5 oversized command list, -6 malformed/out-of-bounds command.
 * The full list is validated before begin_frame is called. */
int st_platform_present(const st_platform_adapter_t *platform, const st_draw_list_t *list);
#endif

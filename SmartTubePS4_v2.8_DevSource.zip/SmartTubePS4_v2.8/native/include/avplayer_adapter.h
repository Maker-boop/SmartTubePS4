#ifndef STPS4_AVPLAYER_ADAPTER_H
#define STPS4_AVPLAYER_ADAPTER_H

#include "media_backend.h"
#include <stdbool.h>

typedef struct {
    void *context;
    bool (*open_source)(void *context, const char *uri);
    bool (*start)(void *context);
    bool (*pause)(void *context);
    bool (*seek_seconds)(void *context, double seconds);
    bool (*query_time)(void *context, double *position, double *duration);
    void (*close_source)(void *context);
} st_avplayer_ops_t;

typedef struct {
    st_avplayer_ops_t ops;
    bool source_open;
} st_avplayer_adapter_t;

/* Binds a platform AV-player implementation to the portable media contract.
 * The platform must supply real decoder/output operations; this module does
 * not pretend to implement or emulate the PS4 AV player itself. */
bool st_avplayer_adapter_init(st_avplayer_adapter_t *adapter,
                              const st_avplayer_ops_t *ops,
                              st_media_backend_t *backend);

#endif

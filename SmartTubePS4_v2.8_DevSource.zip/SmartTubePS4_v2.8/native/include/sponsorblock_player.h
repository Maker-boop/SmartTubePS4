#ifndef STPS4_SPONSORBLOCK_PLAYER_H
#define STPS4_SPONSORBLOCK_PLAYER_H
#include "media_backend.h"
#include "sponsorblock_pipeline.h"

typedef enum {
    SB_PLAYER_NO_ACTION = 0,
    SB_PLAYER_SEEKED = 1,
    SB_PLAYER_ERR_ARGUMENT = -1,
    SB_PLAYER_ERR_BACKEND = -2,
    SB_PLAYER_ERR_POSITION = -3,
    SB_PLAYER_ERR_SEEK = -4
} sb_player_result_t;

typedef struct {
    double last_skipped_start;
    double last_skipped_end;
    int has_last_skipped;
} sb_player_state_t;

/* Call periodically while playing. A segment is skipped only when playback is
 * within trigger_window_seconds of its start (or already inside it). State
 * prevents repeated seeks for the same segment. A rewind before the last
 * skipped segment rearms it. Reset state explicitly on media change. */
void sb_player_state_reset(sb_player_state_t *state);
sb_player_result_t sb_player_tick(st_media_backend_t *backend,
    const sb_pipeline_result_t *segments, const sb_preferences_t *preferences,
    double duration_seconds, double trigger_window_seconds,
    sb_player_state_t *state, sb_segment_t *skipped_segment);
#endif

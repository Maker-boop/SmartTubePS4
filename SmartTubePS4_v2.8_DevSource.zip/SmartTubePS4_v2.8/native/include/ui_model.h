#ifndef STPS4_UI_MODEL_H
#define STPS4_UI_MODEL_H
#include "app_state.h"
#define ST_UI_MAX_ITEMS 8
#define ST_UI_TEXT_MAX 96
typedef struct { char label[ST_UI_TEXT_MAX]; char detail[ST_UI_TEXT_MAX]; bool selected; } st_ui_item_t;
typedef struct { char title[ST_UI_TEXT_MAX]; char subtitle[ST_UI_TEXT_MAX]; st_screen_t screen; unsigned count; unsigned focus; st_ui_item_t items[ST_UI_MAX_ITEMS]; } st_ui_model_t;
/* Produces renderer-neutral screen data. A PS4 graphics adapter must draw it. */
void st_ui_build_model(const st_app_state_t *state, st_ui_model_t *out);
#endif

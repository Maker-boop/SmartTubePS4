#ifndef STPS4_APP_STATE_H
#define STPS4_APP_STATE_H
#include <stdbool.h>
#include <stddef.h>

typedef enum { ST_SCREEN_HOME=0, ST_SCREEN_SEARCH, ST_SCREEN_LIBRARY, ST_SCREEN_SETTINGS, ST_SCREEN_PLAYER, ST_SCREEN_ABOUT } st_screen_t;
typedef enum { ST_ACT_NONE=0, ST_ACT_UP, ST_ACT_DOWN, ST_ACT_LEFT, ST_ACT_RIGHT, ST_ACT_CONFIRM, ST_ACT_BACK, ST_ACT_PLAY_PAUSE, ST_ACT_SEEK_BACK, ST_ACT_SEEK_FORWARD, ST_ACT_EXIT } st_action_t;
typedef struct {
    st_screen_t screen;
    unsigned focus_index;
    unsigned item_count;
    bool playing;
    bool has_video;
    bool should_exit;
    bool shutdown_notified;
    double position_seconds;
    double duration_seconds;
} st_app_state_t;
void st_app_init(st_app_state_t *state);
void st_app_set_items(st_app_state_t *state, unsigned count);
void st_app_dispatch(st_app_state_t *state, st_action_t action);
#endif

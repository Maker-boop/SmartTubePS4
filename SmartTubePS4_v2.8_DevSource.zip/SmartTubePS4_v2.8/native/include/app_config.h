#ifndef SMARTTUBE_PS4_APP_CONFIG_H
#define SMARTTUBE_PS4_APP_CONFIG_H

#define APP_TITLE "SmartTube PS4"
#define APP_VERSION "2.8.0-dev"
#define APP_TARGET_PLATFORM "PlayStation 4"

#endif

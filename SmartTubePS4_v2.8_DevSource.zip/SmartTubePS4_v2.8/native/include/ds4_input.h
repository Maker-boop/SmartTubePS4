#ifndef STPS4_DS4_INPUT_H
#define STPS4_DS4_INPUT_H

#include "controller_map.h"
#include <stdbool.h>
#include <stdint.h>

/* DualShock 4 button bit values documented by the OpenOrbis Pad headers. */
#define ST_DS4_UP        0x0010u
#define ST_DS4_RIGHT     0x0020u
#define ST_DS4_DOWN      0x0040u
#define ST_DS4_LEFT      0x0080u
#define ST_DS4_L1        0x0400u
#define ST_DS4_R1        0x0800u
#define ST_DS4_TRIANGLE  0x1000u
#define ST_DS4_CIRCLE    0x2000u
#define ST_DS4_CROSS     0x4000u
#define ST_DS4_SQUARE    0x8000u
#define ST_DS4_OPTIONS   0x0008u

#define ST_DS4_EVENT_CAPACITY 10u /* one slot per mapped button */

typedef struct {
    uint32_t previous_buttons;
    st_pad_button_t events[ST_DS4_EVENT_CAPACITY];
    unsigned event_count;
    unsigned event_index;
} st_ds4_input_t;

void st_ds4_input_init(st_ds4_input_t *input);
/* Converts a sampled hardware button mask into one-shot press events. */
void st_ds4_input_update(st_ds4_input_t *input, uint32_t buttons);
/* Returns 1 with an event, 0 when empty, or -1 for invalid arguments. */
int st_ds4_input_poll(st_ds4_input_t *input, st_pad_button_t *button);

#endif

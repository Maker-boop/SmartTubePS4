#ifndef STPS4_PLAYER_BACKEND_H
#define STPS4_PLAYER_BACKEND_H
#include <stdbool.h>
typedef struct {
    void *context;
    bool (*open)(void *context, const char *authorized_media_uri);
    bool (*play)(void *context);
    bool (*pause)(void *context);
    bool (*seek)(void *context, double seconds);
    void (*close)(void *context);
} st_player_backend_t;
/* Adapter contract only. A PS4-compatible decoder/output backend is still required. */
#endif

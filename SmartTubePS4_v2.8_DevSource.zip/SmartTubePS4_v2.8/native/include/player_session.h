#ifndef STPS4_PLAYER_SESSION_H
#define STPS4_PLAYER_SESSION_H

#include "media_backend.h"
#include <stdbool.h>

typedef enum {
    ST_PLAYER_IDLE = 0,
    ST_PLAYER_OPEN = 1,
    ST_PLAYER_PLAYING = 2,
    ST_PLAYER_PAUSED = 3,
    ST_PLAYER_ENDED = 4,
    ST_PLAYER_ERROR = 5
} st_player_state_t;

typedef enum {
    ST_PLAYER_OK = 0,
    ST_PLAYER_ERR_ARGUMENT = -1,
    ST_PLAYER_ERR_URI = -2,
    ST_PLAYER_ERR_BACKEND = -3,
    ST_PLAYER_ERR_STATE = -4,
    ST_PLAYER_ERR_POSITION = -5
} st_player_result_t;

typedef struct {
    st_media_backend_t *backend;
    st_player_state_t state;
    double position_seconds;
    double duration_seconds;
    unsigned long media_generation;
} st_player_session_t;

void st_player_session_init(st_player_session_t *session, st_media_backend_t *backend);
/* Accepts local file:// URIs and HTTP(S) URLs. The backend remains responsible
 * for provider authorization, TLS, decoding, and output. */
bool st_player_uri_is_supported(const char *uri);
st_player_result_t st_player_session_open(st_player_session_t *session, const char *uri);
st_player_result_t st_player_session_play(st_player_session_t *session);
st_player_result_t st_player_session_pause(st_player_session_t *session);
st_player_result_t st_player_session_seek(st_player_session_t *session, double seconds);
st_player_result_t st_player_session_update(st_player_session_t *session);
void st_player_session_close(st_player_session_t *session);

#endif

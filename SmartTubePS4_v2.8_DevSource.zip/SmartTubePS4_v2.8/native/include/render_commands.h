#ifndef STPS4_RENDER_COMMANDS_H
#define STPS4_RENDER_COMMANDS_H
#include <stddef.h>
#include <stdint.h>
#include "ui_model.h"
#define ST_RENDER_MAX_COMMANDS 64
#define ST_RENDER_WIDTH 1920.0f
#define ST_RENDER_HEIGHT 1080.0f
#define ST_COLOR_BG 0x10131BFFu
#define ST_COLOR_PANEL 0x1A2030FFu
#define ST_COLOR_PANEL_ALT 0x222B3DFFu
#define ST_COLOR_BLUE 0x258BFFFFu
#define ST_COLOR_WHITE 0xF2F5FAFFu
#define ST_COLOR_MUTED 0x9AA7B8FFu
#define ST_COLOR_FOCUS 0x254C78FFu
#define ST_COLOR_FOCUS_EDGE 0x55B2FFFFu
typedef enum {
    ST_DRAW_RECT=1,
    ST_DRAW_TEXT=2,
    ST_DRAW_LINE=3,
    ST_DRAW_OUTLINE_RECT=4
} st_draw_kind_t;
typedef struct {
    st_draw_kind_t kind;
    float x, y, w, h;
    uint32_t color;
    char text[ST_UI_TEXT_MAX];
} st_draw_command_t;
typedef struct { unsigned count; st_draw_command_t commands[ST_RENDER_MAX_COMMANDS]; } st_draw_list_t;
/* Builds a renderer-neutral 1920x1080 dashboard frame. No PS4 graphics calls are made here. */
void st_render_build(const st_ui_model_t *model, st_draw_list_t *out);
#endif

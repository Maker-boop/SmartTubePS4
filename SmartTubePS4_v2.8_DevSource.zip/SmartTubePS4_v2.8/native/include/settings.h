#ifndef STPS4_SETTINGS_H
#define STPS4_SETTINGS_H
#include <stdbool.h>
typedef struct { bool sponsor_skip_enabled; bool skip_sponsor; bool skip_self_promo; bool skip_intro; bool skip_outro; bool skip_interaction; bool skip_music_offtopic; bool skip_preview; } st_settings_t;
void st_settings_defaults(st_settings_t *s);
/* Portable key=value persistence; caller supplies a writable path. */
bool st_settings_save(const st_settings_t *s, const char *path);
bool st_settings_load(st_settings_t *s, const char *path);
#endif

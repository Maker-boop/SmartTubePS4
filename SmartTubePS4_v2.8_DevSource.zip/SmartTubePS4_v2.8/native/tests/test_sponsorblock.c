#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "sponsorblock.h"

int main(void) {
    sb_preferences_t prefs = {{0}, 1, 1.0};
    sb_segment_t segments[] = {
        {30.0, 42.0, SB_CATEGORY_SPONSOR, 0},
        {50.0, 55.0, SB_CATEGORY_INTRO, 0},
        {60.0, 64.0, SB_CATEGORY_OUTRO, 1}
    };
    sb_segment_t found;

    prefs.enabled[SB_CATEGORY_SPONSOR] = 1;
    prefs.enabled[SB_CATEGORY_INTRO] = 0;
    assert(sb_segment_is_valid(&segments[0], 120.0));
    assert(!sb_segment_is_valid(&(sb_segment_t){10.0, 9.0, SB_CATEGORY_SPONSOR, 0}, 120.0));
    assert(sb_should_skip(&segments[0], &prefs, 120.0));
    assert(!sb_should_skip(&segments[1], &prefs, 120.0));
    assert(sb_should_skip(&segments[2], &prefs, 120.0)); /* mandatory segment */

    assert(sb_find_next_segment(segments, 3, &prefs, 120.0, 20.0, 20.0, &found));
    assert(found.category == SB_CATEGORY_SPONSOR);
    assert(strcmp(sb_category_api_name(SB_CATEGORY_OFF_TOPIC_MUSIC), "music_offtopic") == 0);
    assert(!sb_find_next_segment(segments, 3, &prefs, 120.0, 43.0, 2.0, &found));

    puts("SponsorBlock core tests passed.");
    return 0;
}

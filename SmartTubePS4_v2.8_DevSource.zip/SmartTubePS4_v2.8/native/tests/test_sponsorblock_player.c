#include "sponsorblock_player.h"
#include <assert.h>
#include <stdio.h>
typedef struct { double pos, duration, seek_to; int seeks; st_media_result_t seek_rc; } fake_t;
static st_media_result_t open_fn(void *c,const char *u){(void)c;(void)u;return ST_MEDIA_OK;}
static st_media_result_t play_fn(void *c){(void)c;return ST_MEDIA_OK;}
static st_media_result_t pause_fn(void *c){(void)c;return ST_MEDIA_OK;}
static st_media_result_t seek_fn(void *c,double t){fake_t*f=c;f->seeks++;f->seek_to=t;return f->seek_rc;}
static st_media_result_t pos_fn(void *c,double*p,double*d){fake_t*f=c;*p=f->pos;*d=f->duration;return ST_MEDIA_OK;}
static void close_fn(void*c){(void)c;}
int main(void){
 fake_t f={10.0,100.0,0,0,ST_MEDIA_OK};
 st_media_backend_t b={&f,open_fn,play_fn,pause_fn,seek_fn,pos_fn,close_fn};
 sb_segment_t data[]={{12.0,28.0,SB_CATEGORY_SPONSOR,0}}, skipped;
 sb_pipeline_result_t r={data,1,1,200}; sb_preferences_t p={{0},1,0.0};
 sb_player_state_t state; sb_player_state_reset(&state); p.enabled[SB_CATEGORY_SPONSOR]=1;
 assert(sb_player_tick(&b,&r,&p,100.0,1.0,&state,&skipped)==SB_PLAYER_NO_ACTION);
 f.pos=11.5;
 assert(sb_player_tick(&b,&r,&p,100.0,1.0,&state,&skipped)==SB_PLAYER_SEEKED);
 assert(f.seeks==1 && f.seek_to==28.0 && skipped.start_seconds==12.0);
 f.pos=12.0;
 assert(sb_player_tick(&b,&r,&p,100.0,1.0,&state,&skipped)==SB_PLAYER_NO_ACTION && f.seeks==1);
 /* Rewinding before the skipped segment rearms automatic skipping. */
 f.pos=5.0;
 assert(sb_player_tick(&b,&r,&p,100.0,1.0,&state,&skipped)==SB_PLAYER_NO_ACTION);
 f.pos=11.5;
 assert(sb_player_tick(&b,&r,&p,100.0,1.0,&state,&skipped)==SB_PLAYER_SEEKED && f.seeks==2);
 sb_player_state_reset(&state); f.pos=20.0; f.seek_rc=ST_MEDIA_ERR_FAILED;
 assert(sb_player_tick(&b,&r,&p,100.0,1.0,&state,&skipped)==SB_PLAYER_ERR_SEEK);
 assert(skipped.start_seconds==0.0 && skipped.end_seconds==0.0);
 p.automatic_skip=0;
 assert(sb_player_tick(&b,&r,&p,100.0,1.0,&state,&skipped)==SB_PLAYER_NO_ACTION);
 puts("SponsorBlock player seek integration tests passed."); return 0;
}

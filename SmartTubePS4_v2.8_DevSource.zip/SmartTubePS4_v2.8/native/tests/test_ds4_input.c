#include "ds4_input.h"
#include <assert.h>
#include <stdio.h>

int main(void) {
    st_ds4_input_t input;
    st_pad_button_t button;
    st_ds4_input_init(&input);

    st_ds4_input_update(&input, ST_DS4_CROSS | ST_DS4_UP);
    assert(st_ds4_input_poll(&input, &button) == 1 && button == ST_PAD_UP);
    assert(st_ds4_input_poll(&input, &button) == 1 && button == ST_PAD_CROSS);
    assert(st_ds4_input_poll(&input, &button) == 0);

    /* Holding a button must not repeatedly trigger it. */
    st_ds4_input_update(&input, ST_DS4_CROSS | ST_DS4_UP);
    assert(st_ds4_input_poll(&input, &button) == 0);

    /* Release then press again produces a new event. */
    st_ds4_input_update(&input, 0);
    st_ds4_input_update(&input, ST_DS4_CROSS);
    assert(st_ds4_input_poll(&input, &button) == 1 && button == ST_PAD_CROSS);
    assert(st_ds4_input_poll(&input, &button) == 0);

    st_ds4_input_update(&input, ST_DS4_OPTIONS | ST_DS4_L1 | ST_DS4_R1);
    assert(st_ds4_input_poll(&input, &button) == 1 && button == ST_PAD_L1);
    assert(st_ds4_input_poll(&input, &button) == 1 && button == ST_PAD_R1);
    assert(st_ds4_input_poll(&input, &button) == 1 && button == ST_PAD_OPTIONS);
    assert(st_ds4_input_poll(&input, &button) == 0);

    assert(st_ds4_input_poll(NULL, &button) == -1);
    assert(st_ds4_input_poll(&input, NULL) == -1);
    puts("DualShock 4 input edge and queue tests passed.");
    return 0;
}

#include "sponsorblock_pipeline.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef struct { const char *body; int called; } fake_t;
static sb_https_result_t fake_get(void *ctx,const char *url,char *out,size_t cap,size_t *len,long *status) {
    fake_t *f=(fake_t *)ctx; size_t n=strlen(f->body); f->called++;
    assert(strstr(url,"/api/skipSegments/")); assert(!strstr(url,"dQw4w9WgXcQ"));
    assert(n<cap); memcpy(out,f->body,n); *len=n; *status=200; return SB_HTTPS_OK;
}
int main(void) {
    const char *json="{\"dQw4w9WgXcQ\":[{\"category\":\"sponsor\",\"segment\":[12.0,28.0],\"UUID\":\"x\",\"actionType\":\"skip\"}],\"abcdefghijk\":[]}";
    sb_preferences_t p={{0},1,0.0}; sb_segment_t segs[4], next; char body[1024];
    sb_pipeline_result_t r={segs,4,0,0}; fake_t f={json,0};
    p.enabled[SB_CATEGORY_SPONSOR]=1;
    assert(sb_pipeline_fetch_segments("dQw4w9WgXcQ",&p,100.0,body,sizeof body,&r,fake_get,&f)==SB_HTTPS_OK);
    assert(f.called==1 && r.count==1 && r.http_status==200);
    assert(sb_pipeline_next_skip(&r,&p,100.0,10.0,5.0,&next)==1);
    assert(next.start_seconds==12.0 && next.end_seconds==28.0);
    assert(sb_pipeline_next_skip(&r,&p,100.0,30.0,5.0,&next)==0);
    puts("SponsorBlock end-to-end pipeline tests passed."); return 0;
}

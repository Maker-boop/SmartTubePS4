#include "sponsorblock_client.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void) {
    sb_preferences_t prefs = {{0}, 1, 0.0};
    char url[1024];
    prefs.enabled[SB_CATEGORY_SPONSOR] = 1;
    prefs.enabled[SB_CATEGORY_SELF_PROMO] = 1;

    assert(sb_build_skip_segments_url("dQw4w9WgXcQ", &prefs, url, sizeof(url)) == SB_CLIENT_OK);
    assert(strstr(url, "https://sponsor.ajay.app/api/skipSegments?videoID=dQw4w9WgXcQ") == url);
    assert(strstr(url, "&actionType=skip&service=YouTube") != NULL);
    assert(strstr(url, "&category=sponsor") != NULL);
    assert(strstr(url, "&category=selfpromo") != NULL);

    assert(sb_build_skip_segments_url("not-a$video", &prefs, url, sizeof(url)) == SB_CLIENT_ERR_VIDEO_ID);
    assert(sb_build_skip_segments_url("dQw4w9WgXcQ", &prefs, url, 8) == SB_CLIENT_ERR_BUFFER);
    prefs.enabled[SB_CATEGORY_SPONSOR] = 0;
    prefs.enabled[SB_CATEGORY_SELF_PROMO] = 0;
    assert(sb_build_skip_segments_url("dQw4w9WgXcQ", &prefs, url, sizeof(url)) == SB_CLIENT_ERR_NO_CATEGORIES);
    assert(url[0] == '\0');
    puts("SponsorBlock client request tests passed.");
    return 0;
}

#include "runtime.h"
#include <assert.h>
#include <stdio.h>

typedef struct {
    const st_pad_button_t *events;
    unsigned count;
    unsigned index;
    unsigned begins, ends, draws, shutdowns;
    int fail_at;
} fake_platform_t;

static int poll(void *ctx, st_pad_button_t *button) {
    fake_platform_t *f = (fake_platform_t *)ctx;
    if (f->fail_at >= 0 && (int)f->index == f->fail_at) return -1;
    if (f->index >= f->count) return 0;
    *button = f->events[f->index++];
    return 1;
}
static int begin(void *ctx) { ((fake_platform_t *)ctx)->begins++; return 0; }
static int draw(void *ctx, const st_draw_command_t *cmd) {
    fake_platform_t *f = (fake_platform_t *)ctx;
    assert(cmd); f->draws++; return 0;
}
static int end(void *ctx) { ((fake_platform_t *)ctx)->ends++; return 0; }
static void shutdown_platform(void *ctx) { ((fake_platform_t *)ctx)->shutdowns++; }

int main(void) {
    st_app_state_t state;
    st_platform_adapter_t platform = {0};
    fake_platform_t fake = {0};
    const st_pad_button_t navigation[] = {ST_PAD_DOWN, ST_PAD_DOWN, ST_PAD_UP};
    const st_pad_button_t exit_event[] = {ST_PAD_OPTIONS};
    st_app_init(&state);
    fake.events = navigation; fake.count = 3; fake.fail_at = -1;
    platform.context = &fake;
    platform.poll_button = poll;
    platform.begin_frame = begin;
    platform.draw = draw;
    platform.end_frame = end;
    platform.shutdown = shutdown_platform;

    assert(st_runtime_frame(&state, &platform) == ST_RUNTIME_OK);
    assert(state.focus_index == 1); /* two down, then one up */
    assert(fake.index == 3);
    assert(fake.begins == 1 && fake.ends == 1 && fake.draws > 0);

    fake.events = exit_event; fake.count = 1; fake.index = 0;
    {
        unsigned old_begins = fake.begins, old_draws = fake.draws;
        assert(st_runtime_frame(&state, &platform) == ST_RUNTIME_EXIT_REQUESTED);
        assert(state.should_exit && state.shutdown_notified);
        assert(fake.index == 1 && fake.shutdowns == 1);
        assert(fake.begins == old_begins && fake.draws == old_draws);
        assert(st_runtime_frame(&state, &platform) == ST_RUNTIME_EXIT_REQUESTED);
        assert(fake.shutdowns == 1); /* shutdown callback is idempotent */
    }

    st_app_init(&state);
    fake.events = navigation; fake.count = 3; fake.index = 0;
    fake.fail_at = 1;
    assert(st_runtime_frame(&state, &platform) == ST_RUNTIME_ERR_INPUT);
    assert(state.focus_index == 1); /* first event was applied before platform error */

    assert(st_runtime_frame(NULL, &platform) == ST_RUNTIME_ERR_ARGUMENT);
    puts("runtime event-batching and shutdown lifecycle tests passed");
    return 0;
}

#include "sponsorblock_https.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void) {
    sb_preferences_t p={{0},1,0.0}; char url[1024]; size_t n; long status; char body[8];
    p.enabled[SB_CATEGORY_SPONSOR]=1; p.enabled[SB_CATEGORY_INTRO]=1;
    assert(sb_build_private_skip_url("dQw4w9WgXcQ",&p,url,sizeof url)==SB_HTTPS_OK);
    assert(strstr(url,"/api/skipSegments/5f6b?service=YouTube") != NULL);
    assert(strstr(url,"&category=sponsor") && strstr(url,"&category=intro"));
    assert(!strstr(url,"dQw4w9WgXcQ"));
    assert(sb_build_private_skip_url("bad",&p,url,sizeof url)==SB_HTTPS_ERR_ARGUMENT);
    p.enabled[SB_CATEGORY_SPONSOR]=p.enabled[SB_CATEGORY_INTRO]=0;
    assert(sb_build_private_skip_url("dQw4w9WgXcQ",&p,url,sizeof url)==SB_HTTPS_ERR_URL);
    assert(sb_https_get("http://sponsor.ajay.app/",body,sizeof body,&n,&status)==SB_HTTPS_ERR_URL);
    puts("SponsorBlock HTTPS/privacy tests passed."); return 0;
}

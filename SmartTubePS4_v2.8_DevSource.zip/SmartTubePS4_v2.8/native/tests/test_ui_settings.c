#include "ui_model.h"
#include "settings.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void) {
 st_app_state_t state; st_app_init(&state); st_ui_model_t model;
 st_ui_build_model(&state,&model); assert(model.count==5); assert(!strcmp(model.title,"SmartTube PS4")); assert(model.items[0].selected);
 state.screen=ST_SCREEN_SETTINGS; state.focus_index=99; st_ui_build_model(&state,&model); assert(model.count==4); assert(model.focus==3); assert(model.items[3].selected);
 st_settings_t a,b; st_settings_defaults(&a); assert(a.sponsor_skip_enabled && a.skip_sponsor && !a.skip_intro);
 const char *path="/tmp/smarttube-ps4-settings-test.cfg"; assert(st_settings_save(&a,path)); memset(&b,0,sizeof(b)); assert(st_settings_load(&b,path)); assert(b.sponsor_skip_enabled && b.skip_self_promo && !b.skip_outro);
 remove(path); puts("UI model and settings tests passed."); return 0;
}

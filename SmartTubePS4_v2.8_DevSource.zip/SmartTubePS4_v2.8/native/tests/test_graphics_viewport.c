#include "graphics_viewport.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
int main(void) {
    st_graphics_viewport_t v;
    st_draw_command_t in, out;
    memset(&in, 0, sizeof(in)); in.kind=ST_DRAW_RECT; in.x=0; in.y=0; in.w=1920; in.h=1080;
    assert(st_graphics_viewport_init(&v,1920,1080)==0);
    assert(fabsf(v.scale-1.0f)<0.0001f && v.offset_x==0 && v.offset_y==0);
    assert(st_graphics_viewport_map(&v,&in,&out)==0);
    assert(out.x==0 && out.y==0 && out.w==1920 && out.h==1080);
    assert(st_graphics_viewport_init(&v,1280,1024)==0);
    assert(fabsf(v.scale-(1280.0f/1920.0f))<0.0001f);
    assert(v.offset_x==0 && v.offset_y>0);
    in.x=100; in.y=100; in.w=200; in.h=100;
    assert(st_graphics_viewport_map(&v,&in,&out)==0);
    assert(fabsf(out.x-(v.offset_x+100*v.scale))<0.001f);
    assert(fabsf(out.y-(v.offset_y+100*v.scale))<0.001f);
    in.x=1900; in.w=100;
    assert(st_graphics_viewport_map(&v,&in,&out)==-1);
    assert(st_graphics_viewport_init(&v,0,720)==-1);
    assert(st_graphics_viewport_init(NULL,1280,720)==-1);

    /* Reject corrupted or manually fabricated viewport state. */
    st_graphics_viewport_t bad = v;
    bad.output_width = 0;
    assert(st_graphics_viewport_map(&bad,&in,&out)==-1);
    bad = v; bad.offset_x = NAN;
    assert(st_graphics_viewport_map(&bad,&in,&out)==-1);
    bad = v; bad.scale = 2.0f;
    assert(st_graphics_viewport_map(&bad,&in,&out)==-1);
    in.kind = (st_draw_kind_t)99;
    assert(st_graphics_viewport_map(&v,&in,&out)==-1);
    puts("graphics viewport tests passed"); return 0;
}

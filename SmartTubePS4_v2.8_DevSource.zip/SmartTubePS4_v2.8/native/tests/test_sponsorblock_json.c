#include "sponsorblock_json.h"
#include <assert.h>
#include <stdio.h>

int main(void) {
    const char *body = "[{\"category\":\"sponsor\",\"segment\":[12.5,35.0],\"UUID\":\"abc\",\"votes\":3},"
                       "{\"segment\":[40,44],\"category\":\"intro\",\"locked\":0},"
                       "{\"category\":\"unknown\",\"segment\":[50,55]}]";
    sb_segment_t segments[2]; size_t count=99;
    assert(sb_parse_skip_segments_json(body,100.0,segments,2,&count)==SB_JSON_OK);
    assert(count==2);
    assert(segments[0].category==SB_CATEGORY_SPONSOR && segments[0].start_seconds==12.5);
    assert(segments[1].category==SB_CATEGORY_INTRO && segments[1].end_seconds==44.0);
    assert(sb_parse_skip_segments_json(body,100.0,segments,1,&count)==SB_JSON_ERR_CAPACITY && count==0);
    assert(sb_parse_skip_segments_json("[{\"category\":\"sponsor\",\"segment\":[1,2]}",100,segments,2,&count)==SB_JSON_ERR_MALFORMED);
    assert(count==0);
    assert(sb_parse_skip_segments_json("[]",100,segments,2,&count)==SB_JSON_OK && count==0);
    {
        const char *kanon = "{\"aaaaaaaaaaa\":[{\"category\":\"sponsor\",\"segment\":[1,8]}],"
                           "\"dQw4w9WgXcQ\":[{\"category\":\"intro\",\"segment\":[9,12]}]}";
        assert(sb_parse_kanon_response_json(kanon,"dQw4w9WgXcQ",30.0,segments,2,&count)==SB_JSON_OK);
        assert(count==1 && segments[0].category==SB_CATEGORY_INTRO);
        assert(segments[0].start_seconds==9.0 && segments[0].end_seconds==12.0);
        assert(sb_parse_kanon_response_json(kanon,"bbbbbbbbbbb",30.0,segments,2,&count)==SB_JSON_OK && count==0);
        assert(sb_parse_kanon_response_json(kanon,"dQw4w9WgXcQ",30.0,segments,0,&count)==SB_JSON_ERR_ARGUMENT);
        assert(sb_parse_kanon_response_json("{bad}","dQw4w9WgXcQ",30.0,segments,2,&count)==SB_JSON_ERR_MALFORMED && count==0);
    }
    puts("sponsorblock_json: ok"); return 0;
}

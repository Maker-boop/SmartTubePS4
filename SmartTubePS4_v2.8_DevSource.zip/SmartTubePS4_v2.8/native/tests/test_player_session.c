#include "player_session.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>

typedef struct {
    double position, duration, seek_to;
    int opens, plays, pauses, closes;
    st_media_result_t fail_play;
} fake_t;
static st_media_result_t op(void *p, const char *uri) { fake_t *f=p; (void)uri; f->opens++; f->position=0; f->duration=90; return ST_MEDIA_OK; }
static st_media_result_t play(void *p) { fake_t *f=p; f->plays++; return f->fail_play; }
static st_media_result_t pause(void *p) { ((fake_t *)p)->pauses++; return ST_MEDIA_OK; }
static st_media_result_t seek(void *p, double t) { fake_t *f=p; f->seek_to=t; f->position=t; return ST_MEDIA_OK; }
static st_media_result_t pos(void *p, double *t, double *d) { fake_t *f=p; *t=f->position; *d=f->duration; return ST_MEDIA_OK; }
static void close_media(void *p) { ((fake_t *)p)->closes++; }
int main(void) {
    fake_t f={0};
    st_media_backend_t b={&f,op,play,pause,seek,pos,close_media};
    st_player_session_t s;
    st_player_session_init(&s,&b);
    assert(s.state==ST_PLAYER_IDLE);
    assert(st_player_uri_is_supported("https://media.example/video.mp4"));
    assert(st_player_uri_is_supported("file:///data/video.mp4"));
    assert(!st_player_uri_is_supported("javascript:alert(1)"));
    assert(st_player_session_play(&s)==ST_PLAYER_ERR_STATE);
    assert(st_player_session_open(&s,"https://media.example/video.mp4")==ST_PLAYER_OK);
    assert(s.state==ST_PLAYER_OPEN && f.opens==1 && s.media_generation==1);
    assert(st_player_session_update(&s)==ST_PLAYER_OK && s.duration_seconds==90);
    assert(st_player_session_play(&s)==ST_PLAYER_OK && s.state==ST_PLAYER_PLAYING);
    assert(st_player_session_seek(&s,120)==ST_PLAYER_OK && f.seek_to==90);
    f.position=89.98;
    assert(st_player_session_update(&s)==ST_PLAYER_OK && s.state==ST_PLAYER_ENDED);
    assert(st_player_session_seek(&s,30)==ST_PLAYER_OK && s.state==ST_PLAYER_PAUSED);
    st_player_session_close(&s);
    assert(s.state==ST_PLAYER_IDLE && f.closes==1);
    assert(st_player_session_open(&s,"https://media.example/next.mp4")==ST_PLAYER_OK);
    f.fail_play=ST_MEDIA_ERR_FAILED;
    assert(st_player_session_play(&s)==ST_PLAYER_ERR_BACKEND && s.state==ST_PLAYER_ERROR);
    st_player_session_close(&s);
    assert(f.closes==2);
    assert(st_player_session_open(&s,"ftp://media.example/video")==ST_PLAYER_ERR_URI);
    puts("player session tests passed");
    return 0;
}

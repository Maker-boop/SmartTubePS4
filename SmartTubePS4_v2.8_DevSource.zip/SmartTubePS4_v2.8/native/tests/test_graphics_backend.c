#include "graphics_backend.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

struct fake_gpu { unsigned init, begin, draw, end, stop; int init_fail, begin_fail, draw_fail; uint32_t w, h; };
static int init(void *p, uint32_t w, uint32_t h) { struct fake_gpu *g=p; g->init++; g->w=w; g->h=h; return g->init_fail ? -1 : 0; }
static int begin(void *p) { struct fake_gpu *g=p; g->begin++; return g->begin_fail ? -1 : 0; }
static int draw(void *p, const st_draw_command_t *c) { struct fake_gpu *g=p; assert(c); g->draw++; return g->draw_fail ? -1 : 0; }
static int end(void *p) { ((struct fake_gpu*)p)->end++; return 0; }
static void stop(void *p) { ((struct fake_gpu*)p)->stop++; }

int main(void) {
    struct fake_gpu gpu={0};
    st_graphics_ops_t ops={&gpu,init,begin,draw,end,stop};
    st_graphics_device_t device={0};
    st_draw_list_t list={0};
    list.count=1; list.commands[0].kind=ST_DRAW_RECT;
    list.commands[0].x=10; list.commands[0].y=10;
    list.commands[0].w=100; list.commands[0].h=50;

    assert(st_graphics_device_present(&device,&list)==-1);
    assert(st_graphics_device_init(&device,&ops,319,1080)==-2);
    assert(gpu.init==0);
    assert(st_graphics_device_init(&device,&ops,1920,1080)==0);
    assert(device.initialized && device.width==1920 && device.height==1080);
    assert(gpu.init==1 && gpu.w==1920 && gpu.h==1080);
    assert(st_graphics_device_init(&device,&ops,1280,720)==-3);
    assert(st_graphics_device_present(&device,&list)==0);
    assert(gpu.begin==1 && gpu.draw==1 && gpu.end==1);

    gpu.draw_fail=1;
    assert(st_graphics_device_present(&device,&list)==-3);
    assert(gpu.begin==2 && gpu.end==2);
    st_graphics_device_shutdown(&device);
    st_graphics_device_shutdown(&device);
    assert(gpu.stop==1 && !device.initialized && device.width==0);
    assert(st_graphics_device_present(&device,&list)==-1);

    memset(&device,0,sizeof(device)); memset(&gpu,0,sizeof(gpu)); gpu.init_fail=1;
    assert(st_graphics_device_init(&device,&ops,1280,720)==-4);
    assert(!device.initialized && device.width==0);
    assert(gpu.stop==1); /* partial initialization was cleaned up */

    memset(&device,0,sizeof(device)); memset(&gpu,0,sizeof(gpu));
    assert(st_graphics_device_init(&device,&ops,1280,720)==0);
    gpu.begin_fail=1;
    assert(st_graphics_device_present(&device,&list)==-2);
    assert(gpu.begin==1 && gpu.draw==0 && gpu.end==0);
    st_graphics_device_shutdown(&device);
    puts("graphics backend lifecycle tests passed");
    return 0;
}

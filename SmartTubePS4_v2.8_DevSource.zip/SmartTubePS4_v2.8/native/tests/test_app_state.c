#include <assert.h>
#include "app_state.h"
#include "controller_map.h"
int main(void) {
    st_app_state_t s; st_app_init(&s);
    assert(s.screen==ST_SCREEN_HOME && s.item_count==5 && s.focus_index==0);
    st_app_dispatch(&s, ST_ACT_DOWN); assert(s.focus_index==1);
    st_app_dispatch(&s, ST_ACT_CONFIRM); assert(s.screen==ST_SCREEN_LIBRARY);
    st_app_dispatch(&s, ST_ACT_BACK); assert(s.screen==ST_SCREEN_HOME);
    st_app_set_items(&s,2); st_app_dispatch(&s,ST_ACT_DOWN); assert(s.focus_index==1);
    st_app_set_items(&s,0); assert(s.focus_index==0);
    s.has_video=true; s.duration_seconds=100; s.position_seconds=95; s.screen=ST_SCREEN_PLAYER;
    st_app_dispatch(&s,ST_ACT_RIGHT); assert(s.position_seconds==100);
    st_app_dispatch(&s,ST_ACT_PLAY_PAUSE); assert(s.playing);
    assert(st_controller_map(ST_PAD_CROSS)==ST_ACT_CONFIRM);
    assert(st_controller_map(ST_PAD_CIRCLE)==ST_ACT_BACK);
    return 0;
}

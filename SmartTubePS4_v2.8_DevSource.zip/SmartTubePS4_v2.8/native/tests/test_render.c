#include "render_commands.h"
#include "platform_adapter.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
static unsigned drawn, began, ended;
static int fail_draw;
static int begin(void *p){(void)p;began++;return 0;}
static int draw(void *p,const st_draw_command_t *c){(void)p;assert(c->kind>=ST_DRAW_RECT&&c->kind<=ST_DRAW_OUTLINE_RECT);drawn++;return fail_draw ? -1 : 0;}
static int end(void *p){(void)p;ended++;return 0;}
static void reset(void){drawn=began=ended=0;fail_draw=0;}
int main(void){
 st_ui_model_t m={0}; st_draw_list_t l; m.screen=ST_SCREEN_HOME; m.count=2; m.focus=1;
 snprintf(m.title,sizeof(m.title),"Home"); snprintf(m.subtitle,sizeof(m.subtitle),"Discover videos");
 snprintf(m.items[0].label,sizeof(m.items[0].label),"Featured");
 snprintf(m.items[1].label,sizeof(m.items[1].label),"Continue watching"); m.items[1].selected=1;
 st_render_build(&m,&l); assert(l.count>=20); assert(l.commands[0].kind==ST_DRAW_RECT);
 unsigned outlines=0; for(unsigned i=0;i<l.count;i++) if(l.commands[i].kind==ST_DRAW_OUTLINE_RECT) outlines++;
 assert(outlines>=2);
 st_platform_adapter_t p={0}; p.begin_frame=begin;p.draw=draw;p.end_frame=end;
 assert(st_platform_present(&p,&l)==0);assert(began==1&&ended==1&&drawn==l.count);

 reset(); l.commands[0].x=NAN;
 assert(st_platform_present(&p,&l)==-6); assert(began==0&&drawn==0&&ended==0);
 reset(); l.commands[0].x=-1.0f;
 assert(st_platform_present(&p,&l)==-6); assert(began==0);
 reset(); l.commands[0].kind=(st_draw_kind_t)99;
 assert(st_platform_present(&p,&l)==-6); assert(began==0);
 reset(); l.count=ST_RENDER_MAX_COMMANDS+1u;
 assert(st_platform_present(&p,&l)==-5); assert(began==0);
 reset(); st_render_build(&m,&l); fail_draw=1;
 assert(st_platform_present(&p,&l)==-3); assert(began==1&&ended==1);
 reset(); st_render_build(&m,&l); m.screen=ST_SCREEN_SETTINGS; st_render_build(&m,&l);
 assert(l.count>=10);
 puts("render command and adapter validation tests passed"); return 0;
}

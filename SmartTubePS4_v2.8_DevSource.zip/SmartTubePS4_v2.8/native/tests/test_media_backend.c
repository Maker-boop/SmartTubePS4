#include "media_backend.h"
#include <assert.h>
#include <stdio.h>
typedef struct { double last_seek; int opened; } fake_media_t;
static st_media_result_t open_media(void *c, const char *uri) {
    fake_media_t *f = c; (void)uri; f->opened++; return ST_MEDIA_OK;
}
static st_media_result_t play_media(void *c) { (void)c; return ST_MEDIA_OK; }
static st_media_result_t pause_media(void *c) { (void)c; return ST_MEDIA_OK; }
static st_media_result_t seek_media(void *c, double t) {
    ((fake_media_t *)c)->last_seek = t; return ST_MEDIA_OK;
}
static st_media_result_t position_media(void *c, double *p, double *d) {
    (void)c; *p = 0; *d = 100; return ST_MEDIA_OK;
}
static void close_media(void *c) { (void)c; }
int main(void) {
    fake_media_t fake = {0};
    st_media_backend_t b = {&fake, open_media, play_media, pause_media,
                            seek_media, position_media, close_media};
    assert(st_media_backend_is_valid(&b));
    assert(st_media_open(&b, "https://example.invalid/media") == ST_MEDIA_OK);
    assert(fake.opened == 1);
    assert(st_media_open(&b, "") == ST_MEDIA_ERR_ARGUMENT);
    assert(st_media_seek(&b, 12.5) == ST_MEDIA_OK && fake.last_seek == 12.5);
    assert(st_media_seek(&b, -1) == ST_MEDIA_ERR_ARGUMENT);
    b.seek = 0;
    assert(!st_media_backend_is_valid(&b));
    assert(st_media_seek(&b, 1) == ST_MEDIA_ERR_UNAVAILABLE);
    puts("media backend contract tests passed");
    return 0;
}

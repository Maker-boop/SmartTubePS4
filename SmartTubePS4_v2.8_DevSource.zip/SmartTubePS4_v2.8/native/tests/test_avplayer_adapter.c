#include "avplayer_adapter.h"
#include "player_session.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

typedef struct { double pos, duration; int opens, starts, pauses, seeks, closes; bool fail_start; } fake_av_t;
static bool open_source(void *p, const char *uri) { fake_av_t *f=p; assert(strncmp(uri,"https://",8)==0); f->opens++; f->pos=0; f->duration=120; return true; }
static bool start(void *p) { fake_av_t *f=p; f->starts++; return !f->fail_start; }
static bool pause_source(void *p) { ((fake_av_t *)p)->pauses++; return true; }
static bool seek_source(void *p, double t) { fake_av_t *f=p; f->seeks++; f->pos=t; return true; }
static bool query_time(void *p, double *pos, double *duration) { fake_av_t *f=p; *pos=f->pos; *duration=f->duration; return true; }
static void close_source(void *p) { ((fake_av_t *)p)->closes++; }
int main(void) {
    fake_av_t fake={0};
    st_avplayer_ops_t ops={&fake,open_source,start,pause_source,seek_source,query_time,close_source};
    st_avplayer_adapter_t adapter;
    st_media_backend_t backend;
    st_player_session_t session;
    assert(!st_avplayer_adapter_init(&adapter,&ops,NULL));
    assert(st_avplayer_adapter_init(&adapter,&ops,&backend));
    assert(st_media_backend_is_valid(&backend));
    st_player_session_init(&session,&backend);
    assert(st_player_session_open(&session,"https://cdn.example/video.mp4")==ST_PLAYER_OK);
    assert(st_player_session_play(&session)==ST_PLAYER_OK && fake.starts==1);
    assert(st_player_session_pause(&session)==ST_PLAYER_OK && fake.pauses==1);
    assert(st_player_session_seek(&session,42.5)==ST_PLAYER_OK && fake.pos==42.5);
    assert(st_player_session_update(&session)==ST_PLAYER_OK && session.duration_seconds==120);
    st_player_session_close(&session);
    st_player_session_close(&session);
    assert(fake.closes==1 && !adapter.source_open);
    assert(st_player_session_open(&session,"https://cdn.example/second.mp4")==ST_PLAYER_OK);
    fake.fail_start=true;
    assert(st_player_session_play(&session)==ST_PLAYER_ERR_BACKEND);
    st_player_session_close(&session);
    assert(fake.closes==2);
    puts("AV-player adapter tests passed");
    return 0;
}
